# IncidentLens

**Turns raw application logs into an evidence-backed root cause analysis and a ready-to-review post-mortem in minutes — safely.**

IncidentLens is an [APM](https://microsoft.github.io/apm/) package (agent, skills, prompts, hook) for AI coding agents such as Kiro. Point it at a log bundle; it masks secrets, finds where the failure started, explains why with cited log lines, and drafts the post-mortem.

![Sample IncidentLens report](evidence/screenshots/sample-report.png)

---

## 1. The problem and who it's for

During an incident, on-call engineers grep through tens of thousands of log lines across services, match errors against recent changes and guess at the cause. The **loudest** service is usually just where users notice the problem, not where it started. RCA quality depends on who is on call, post-mortems arrive late, and logs contain secrets and personal data, so they can't be pasted into AI tools.

**Intended users:** on-call engineers, SREs, support/operations teams, and embedded/IoT teams who receive log bundles from devices or customer sites.

## 2. How it works (in plain words)

| Step | Who does it | What happens |
|---|---|---|
| 1. Convert | Python | Any supported log format becomes one clean JSON-lines format with a unique ID per line (`L000123`). |
| 2. Redact | Python | Emails, IPs, tokens, passwords, keys and card numbers are masked **before** the AI sees anything. |
| 3. Parse | Python | Tens of thousands of lines become ~10 "clusters" of similar messages, a per-minute timeline, and a short summary: which service went wrong **first**, which is **loudest**, which changes happened just before, which hosts are affected. |
| 4. Reason | AI (skill) | Starts from the symptom, follows the service dependency map, picks the **earliest anomaly in the failing chain (not the loudest)**, matches it to a failure-pattern library, and rejects red herrings — citing exact log lines. Says "insufficient evidence" instead of guessing. |
| 5. Write | AI (skill) | `rca.md`, `timeline.md` (Mermaid), blameless `postmortem.md`, machine-readable `evidence.json`. |
| 6. Check + report | Python | Every cited line must exist; causal sentences without a citation are flagged; all outputs are re-scanned for leaked secrets; a single offline `report.html` is built. |

The AI never reads raw logs: it works from summaries and pulls specific lines by ID. That keeps cost low, results reproducible, and every claim checkable.

**How it fits with CloudWatch, Datadog, Splunk or ELK:** it complements them. Those platforms watch the logs you ship to them. IncidentLens investigates **any log bundle you are handed** — exported from those tools, collected from a customer site with no monitoring stack, or pulled from devices and gateways in the field — locally, with redaction first and cited evidence.

## 3. Install and run

**Prerequisites:** Python 3.10+ (no packages needed), an APM-compatible AI agent (tested in Kiro), the APM CLI.

```bash
# in your workspace
apm install https://<gitlab-host>/<group>/incidentlens.git#v1.0.0 --target kiro
# private GitLab: set GITLAB_APM_PAT (read_repository) or make sure `git clone` of the URL works first
```
APM places the skills in your agent's skill folder (Kiro: `.kiro/skills/`), plus the `incident-analyst` agent and the `/investigate-incident` and `/quick-triage` prompts where the runtime supports them.

**Run in Kiro (new chat):**
```
/run-incident-analysis logs=./my-logs deploys=./deploys.json service_map=./service_map.json symptom="checkout returns 503"
```
or `/investigate-incident ./my-logs ./deploys.json`, or for a fast answer `/quick-triage ./my-logs`.

Open `incident-report/report.html` when it finishes.

**Try it with the bundled synthetic incidents** (from a clone of this repo):
```bash
python examples/generator/generate_incident.py --scenario all          # creates examples/scenarios/*
python examples/evaluation/prepare_eval.py --scenario db-pool-exhaustion --dest ../incidentlens-demo
```
then run the command above on `../incidentlens-demo/case-01/`.

**Same incidents in other formats** (to see the converter at work):
```bash
python examples/generator/export_formats.py --scenario fleet-firmware-crash --format syslog --dest ../incidentlens-demo
python examples/generator/export_formats.py --scenario db-pool-exhaustion --format log4j --dest ../incidentlens-demo
python examples/generator/export_formats.py --scenario cert-expiry --format ecs --dest ../incidentlens-demo
```

## 4. Inputs and outputs

**Inputs**
| Input | Required | Format |
|---|---|---|
| Logs | yes | File or folder. JSON Lines, JSON array, CSV, CloudWatch export, Datadog export, Elastic ECS, or plain text: ISO-timestamp lines, log4j/logback/Spring Boot, Python logging, syslog (RFC 3164/5424), nginx/Apache access logs. Multi-line stack traces are handled. |
| Changes | recommended | `deploys.json`: `[{"event_id", "ts", "service", "change_type": deploy\|config\|infra\|feature_flag, "details"}]` |
| Service map | optional | JSON or simple YAML: `caller: [callee, ...]` |
| Symptom | optional | Free text, e.g. "checkout returns 503" |

**Unknown log format?** The converter stops and shows sample lines; the agent writes a small mapping file (field names or a regex) and re-runs. Conversion itself stays deterministic Python.

**Outputs** (in `incident-report/`): `report.html`, `rca.md`, `timeline.md`, `postmortem.md`, `evidence.json`, `evidence-check.json`, `redaction-report.json` (counts only), and `work/` (redacted logs and parser outputs).

See a full example in [`examples/sample-run/loud-red-herring/`](examples/sample-run/loud-red-herring/).

## 5. Parameters

| Parameter | Default | Notes |
|---|---|---|
| `logs` | — | Required; file or folder |
| `deploys` | none | Strongly recommended |
| `service_map` | none | Optional |
| `symptom` | none | What users saw |
| `mode` | `full` | `full` or `triage` (top hypothesis, ≤10 lines) |
| `format` | `auto` | `jsonl, json, csv, cloudwatch, datadog, ecs, plain` |
| `time_window` | auto | ISO `START/END` |
| `min_severity` | `WARN` | |
| `max_hypotheses` | `3` | |
| `redaction` | `strict` | `strict` or `standard` (keeps private IPv4); cannot be turned off |
| `output_dir` | `./incident-report` | |
| `audience` | `engineering` | `engineering` or `executive` |

## 6. What's in the package

| Type | Name | Purpose |
|---|---|---|
| Skill | `run-incident-analysis` | Workflow: prepare → reason → write → finalize |
| Skill | `redact-logs` | Mask secrets/PII before analysis |
| Skill | `log-parser` | Convert formats, cluster, timeline, fetch evidence lines |
| Skill | `rca-reasoning` | Evidence-backed hypotheses + failure-pattern library |
| Skill | `postmortem-writer` | RCA, timeline, blameless post-mortem, HTML report |
| Skill | `evidence-check` | Citation, schema and leak checks |
| Agent | `incident-analyst` | Persona that follows the workflow (tools: read, write, shell) |
| Prompts | `/investigate-incident`, `/quick-triage` | One-command entry points |
| Hook | `evidence-gate` | Re-checks the report when the agent session stops |

All scripts are Python standard library only. Nothing calls the network. The agent is read-only towards your systems.

## 7. Supported foundation models

<!-- RESULTS:MODELS -->
Tested models and their scores are listed in [`evidence/scorecard.md`](evidence/scorecard.md). Only models that appear there have been tested.
<!-- /RESULTS:MODELS -->

## 8. Evidence of impact

Evaluated on synthetic incidents with hidden answer keys (two fictional systems, nine scenarios: DB pool exhaustion, bad deploy, memory leak, certificate expiry, dependency latency, disk full, a "loudest service is not the cause" case, an embedded firmware rollout affecting 2 of 4 gateways, and a quiet-day control where the correct answer is "no root cause").

<!-- RESULTS:TABLE -->
Results: see [`evidence/scorecard.md`](evidence/scorecard.md) (top-1 accuracy, service accuracy, evidence precision, red-herring rate, redaction recall, evidence-check pass rate, minutes and credits per RCA, comparison with a manual baseline).
<!-- /RESULTS:TABLE -->

Redaction recall in tests: **100%** of planted fake secrets (9 categories × 10 scenarios) removed, with zero false positives on scenario logs.

## 9. Expected benefits

- Minutes instead of hours to a first, evidence-backed root cause.
- Consistent RCA quality regardless of who is on call; red herrings explicitly ruled out.
- Logs can be used with AI safely: redaction first, leak scan last.
- Post-mortem drafts ready the same day.
- Works where observability platforms don't reach: exported bundles, customer sites, devices.

## 10. Safety design and limitations

- Redaction runs first and cannot be disabled; the AI is instructed never to open log files directly, and parsing refuses unredacted input. This is enforced by the workflow and scripts, not by an OS sandbox.
- Every claim must cite log line IDs; `evidence-check` flags uncited causal sentences and fails on invalid citations or leaks.
- Read-only: no remediation is executed, no configs are changed, no network calls.
- See [docs/limitations.md](docs/limitations.md) for known limitations (pattern-based redaction, synthetic validation, runtime hook support, single-incident windows).

## 11. Synthetic data

All data is synthetic: fictional ShopSphere (web shop) and FleetSense (embedded truck telemetry) systems, `example.test` emails, private IP ranges, `FAKE-` tokens and well-known test card numbers. See [SYNTHETIC_DATA.md](SYNTHETIC_DATA.md).

## 12. Built with Kiro

- Specs in `.kiro/specs/` and steering files in `.kiro/steering/` (data rules, structure, contracts, style).
- Kiro agent hooks: a manual README-results sync and a SKILL.md frontmatter check.
- Model strategy: Sonnet writes specs, Haiku executes tasks, Opus reserved for reasoning design and final review; evaluation runs compare models on cost per correct RCA.

## 13. For developers

```bash
pip install -r requirements-dev.txt
python examples/generator/generate_incident.py --scenario all --check   # regenerate + verify against lock file
python -m pytest -q
```
Evaluation: `examples/evaluation/prepare_eval.py` → run in Kiro → `record_run.py` → `run_eval.py` (writes `evidence/scorecard.md`).

Repository layout: `.apm/` (the package), `examples/` (generator, scenarios, evaluation, sample run), `schemas/`, `tests/`, `docs/`, `evidence/`.
