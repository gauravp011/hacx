import json

import pytest

from conftest import REPO, SKILLS, answer, run


@pytest.mark.parametrize("scenario,fmt", [("fleet-firmware-crash", "syslog"), ("db-pool-exhaustion", "log4j"),
                                          ("cert-expiry", "ecs")])
def test_exported_formats_analyse_like_jsonl(tmp_path, scenarios, scenario, fmt):
    r = run(REPO / "examples" / "generator" / "export_formats.py", "--scenario", scenario, "--format", fmt, "--dest", tmp_path)
    assert r.returncode == 0, r.stdout
    case = tmp_path / f"{scenario}-{fmt}"
    assert not (case / "answer.json").exists()
    out = case / "incident-report"
    r = run(SKILLS / "run-incident-analysis" / "scripts" / "prepare_incident.py", "--logs", case / "logs",
            "--deploys", case / "deploys.json", "--service-map", case / "service_map.json", "--output-dir", out)
    assert r.returncode == 0, r.stdout
    a = answer(scenario)
    text = "".join(p.read_text(encoding="utf-8") for p in out.rglob("*") if p.is_file())
    assert not [s for s in a["planted_secrets"] if s["value"] in text]
    s = json.loads((out / "work" / "summary.json").read_text())
    assert any(c["service"] == a["root_cause_service"] and c["level"] in ("ERROR", "FATAL")
               for c in s["notable_clusters"])
    if a.get("affected_hosts"):
        gw = [c for c in s["notable_clusters"] if c["service"] == a["root_cause_service"] and c["level"] == "ERROR"]
        assert gw[0]["only_on_hosts"] == a["affected_hosts"]
