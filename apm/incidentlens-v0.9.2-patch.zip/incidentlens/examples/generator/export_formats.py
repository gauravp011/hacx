"""Export a generated scenario into other real-world log formats, to show IncidentLens is format-agnostic.

Usage:
    python examples/generator/export_formats.py --scenario fleet-firmware-crash --format syslog --dest ../demo-bundle
    python examples/generator/export_formats.py --scenario db-pool-exhaustion --format log4j --dest ../demo-bundle

Formats:
  syslog  RFC 5424 text, one file per service (typical for embedded devices and gateways)
  log4j   Spring Boot / logback text, one file per service, file name = service
  ecs     Elastic Common Schema NDJSON (one combined file, as exported from Kibana)
Writes logs/, deploys.json, service_map.json and symptom.txt into <dest>/<scenario>-<format>/.
Line IDs are NOT kept: the converter assigns new ones, exactly as with a real export. No answer key is copied.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SCEN = REPO / "examples" / "scenarios"
PRI = {"FATAL": 2, "ERROR": 3, "WARN": 4, "INFO": 6, "DEBUG": 7, "TRACE": 7}
FACILITY = 16  # local0


def rows(sid: str):
    out = []
    for f in sorted((SCEN / sid / "logs").glob("*.jsonl")):
        with open(f, encoding="utf-8") as fh:
            out += [json.loads(x) for x in fh if x.strip()]
    return sorted(out, key=lambda r: r["line_id"])


def fmt_syslog(r: dict) -> str:
    pri = FACILITY * 8 + PRI[r["level"]]
    return f"<{pri}>1 {r['ts']} {r.get('host', '-')} {r['service']} - - - {r['msg']}"


def fmt_log4j(r: dict) -> str:
    ts = r["ts"].replace("T", " ").rstrip("Z")
    cls = "com.example." + r["service"].replace("-", ".") + ".App"
    extra = f" status={r['http_status']}" if "http_status" in r else ""
    return f"{ts} {r['level']:>5} 4242 --- [{r.get('host', 'main')}] {cls:<40} : {r['msg']}{extra}"


def fmt_ecs(r: dict) -> str:
    d = {"@timestamp": r["ts"], "log": {"level": r["level"].lower()}, "service": {"name": r["service"]},
         "host": {"name": r.get("host")}, "message": r["msg"], "trace": {"id": r.get("trace_id")}}
    if "http_status" in r:
        d["http"] = {"response": {"status_code": r["http_status"]}}
    return json.dumps(d)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenario", required=True)
    ap.add_argument("--format", choices=["syslog", "log4j", "ecs"], required=True)
    ap.add_argument("--dest", required=True)
    a = ap.parse_args(argv)
    if not (SCEN / a.scenario / "logs").exists():
        print("Generate scenarios first: python examples/generator/generate_incident.py --scenario all")
        return 2
    dest = Path(a.dest).resolve()
    if REPO in dest.parents:
        print("Choose a --dest outside the repository.")
        return 2
    out = dest / f"{a.scenario}-{a.format}"
    if out.exists():
        shutil.rmtree(out)
    (out / "logs").mkdir(parents=True)
    data = rows(a.scenario)
    if a.format == "ecs":
        with open(out / "logs" / "kibana-export.ndjson", "w", encoding="utf-8", newline="\n") as fh:
            fh.writelines(fmt_ecs(r) + "\n" for r in data)
    else:
        f = fmt_syslog if a.format == "syslog" else fmt_log4j
        ext = ".log"
        by_svc: dict[str, list[str]] = {}
        for r in data:
            by_svc.setdefault(r["service"], []).append(f(r))
        for svc, lines in by_svc.items():
            (out / "logs" / f"{svc}{ext}").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    for name in ("deploys.json", "service_map.json"):
        shutil.copy(SCEN / a.scenario / name, out / name)
    cfg = json.loads((REPO / "examples" / "generator" / "scenarios.json").read_text(encoding="utf-8"))
    symptom = next(s["summary"] for s in cfg["scenarios"] if s["id"] == a.scenario)
    (out / "symptom.txt").write_text(symptom + "\n", encoding="utf-8")
    print(f"Exported {len(data)} lines as {a.format} -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
