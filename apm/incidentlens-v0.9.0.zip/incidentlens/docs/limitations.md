# Known limitations

- **Redaction is pattern-based.** It catches e-mails, IPs, tokens, JWTs, key=value secrets, long hex/base64 strings and Luhn-valid card numbers. It does not detect people's names, street addresses or secrets in unusual formats. Outputs are re-scanned with the same detectors, but users should still review reports before sharing.
- **Enforcement is by workflow, not sandbox.** The skills instruct the agent never to open log files, and the parser refuses unredacted input, but an agent with shell access could technically read files it was told not to. Runtime hooks that block file reads differ between agents and are not relied on.
- **Hooks vary by runtime.** The `evidence-gate` hook (re-check on session stop) is non-blocking and only runs where the runtime supports APM hooks.
- **Validated on synthetic data.** Accuracy numbers come from synthetic scenarios with known answers. Real incidents are messier (multiple overlapping faults, missing logs, clock skew).
- **One incident window at a time.** The analysis assumes the logs cover one incident; very long windows with several unrelated incidents reduce accuracy. Use `time_window` to focus.
- **Format conversion is best-effort.** Built-in mappings cover common layouts of CloudWatch, Datadog, ECS, syslog, log4j, Python logging and access logs; unusual layouts need a mapping file.
- **Timestamps:** logs are assumed to share a clock. Syslog RFC 3164 lines have no year; pass `--year` if needed.
- **The failure-pattern library is a starting point** (6 patterns + UNKNOWN). Teams should extend `references/failure-patterns.md` with their own.
- **The AI can still be wrong.** Confidence levels, cited evidence and the rejected red herrings are there so a human can verify quickly; the post-mortem is a draft.
