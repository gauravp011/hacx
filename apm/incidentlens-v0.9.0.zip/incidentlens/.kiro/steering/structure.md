---
inclusion: always
---
# Repository structure

- `.apm/skills/` — shipped skills: `run-incident-analysis` (workflow + prepare/finalize/doctor scripts), `redact-logs`, `log-parser` (convert, parse, cluster, timeline, get_lines), `rca-reasoning` (+ references/failure-patterns.md), `postmortem-writer` (+ assets/ template, render_report.py), `evidence-check`.
- `.apm/agents/incident-analyst.agent.md`, `.apm/prompts/{investigate-incident,quick-triage}.prompt.md`, `.apm/hooks/evidence-gate.json`.
- `examples/generator/` — data-driven generator (`scenarios.json`, `scenarios.lock.json`); `examples/scenarios/` is generated (git-ignored).
- `examples/evaluation/` — prepare_eval.py, record_run.py, run_eval.py, manual_baseline.md.
- `examples/sample-run/` — one complete example output.
- `runs/<scenario>/<model>-run<N>/` — recorded evaluation runs; `evidence/` — scorecard and screenshots.
- `schemas/` — JSON Schemas; `tests/` — pytest suite; `docs/` — public docs (+ private apm-notes.md).
- Skills refer to each other with sibling paths `../<skill>/scripts/...`.
