---
inclusion: always
---
# Data contracts (schemas/ is the source of truth)

- Log line (JSONL): `line_id` (L + 6 digits, unique, time-ordered), `ts` (ISO UTC Z), `service`, `host`, `level` (TRACE|DEBUG|INFO|WARN|ERROR|FATAL), `trace_id`, `msg`, optional `http_status`, `latency_ms`.
- deploys.json: `[{event_id, ts, service, version, change_type: deploy|config|infra|feature_flag, details}]`.
- service_map.json: `{caller: [callees]}` (simple YAML also accepted).
- answer.json: root_cause_id (taxonomy or NONE), root_cause_service (nullable), trigger_event_id (nullable), fault_start, expected_status, affected_hosts, key_evidence_line_ids, supporting_line_ids, red_herrings, planted_secrets.
- evidence.json: status ok|insufficient_evidence; ranked hypotheses {root_cause_id, service, summary, confidence high|medium|low, evidence_line_ids, related_event_ids}; affected_hosts; red_herrings_considered; five_whys; unverified_claims.
- Taxonomy: DB_POOL_EXHAUSTION, BAD_DEPLOY_CODE_ERROR, MEMORY_LEAK, CERT_EXPIRY, DEPENDENCY_LATENCY, DISK_FULL, UNKNOWN.
- runs/<scenario>/<model>-run<N>/meta.json: scenario, model, run, minutes, credits.
