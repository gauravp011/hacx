---
inclusion: always
---
# Project rules (IncidentLens)

- Synthetic data only: fictional ShopSphere and FleetSense systems, `example.test` emails, private IPs, `FAKE-` tokens, well-known test card numbers. Never add real data, hostnames, company names, people or credentials.
- Never commit or quote HANDOVER.md, BUILD_PLAN.md or docs/apm-notes.md (private, git-ignored).
- Never open scenario log files (`examples/scenarios/*/logs/*.jsonl`) in chat; they are 17k–28k lines. Inspect data with scripts that print summaries or at most 20 lines.
- Never read `answer.json` outside generator, evaluation and test work. Never use answer keys to tune skills or references.
- Shipped code under `.apm/` is Python 3.10+ standard library only. Dev code may use pyyaml, jsonschema, pytest.
- No network calls anywhere. The agent is read-only towards systems.
- Every causal claim in outputs cites log line IDs.
