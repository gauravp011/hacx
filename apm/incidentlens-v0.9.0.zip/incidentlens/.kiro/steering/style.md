---
inclusion: fileMatch
fileMatchPattern: "**/*.py"
---
# Python style

- Python 3.10+, type hints, module docstring with a Usage block, small functions.
- pathlib everywhere; always `open(..., encoding="utf-8")`; write JSONL with `newline="\n"`. Must run on Windows.
- Seeded randomness only (`random.Random(seed)`), no wall-clock reads in generators.
- Scripts exit non-zero with a clear one-line message instead of a traceback for expected failures.
- Under `.apm/`: standard library only; enforced by tests/test_pipeline.py.
