# Manual baseline

Time yourself finding the root cause **without IncidentLens** (text editor / grep only), before looking at any agent output for these scenarios. Record honestly; `run_eval.py` reads the table.

| Scenario | Minutes | Correct (yes/no) | Notes |
|---|---|---|---|
| db-pool-exhaustion | | | |
| loud-red-herring | | | |
