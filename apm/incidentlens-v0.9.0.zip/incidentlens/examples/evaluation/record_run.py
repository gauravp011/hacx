"""Store one evaluation run's outputs in runs/<scenario>/<model>-run<N>/ with run metadata.

Usage:
    python examples/evaluation/record_run.py --case case-01 --model sonnet55 --run 1 \
        --from ../incidentlens-eval/case-01/incident-report --minutes 4.5 --credits 11.2

--case is resolved through examples/evaluation/blind-map.json (or pass --scenario directly).
Copies evidence.json, rca.md, postmortem.md, timeline.md, evidence-check.json, redaction-report.json, report.html.
Refuses to overwrite an existing run.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
FILES = ("evidence.json", "rca.md", "postmortem.md", "timeline.md", "evidence-check.json", "redaction-report.json",
         "report.html")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--case")
    ap.add_argument("--scenario")
    ap.add_argument("--model", required=True, help="e.g. sonnet55, haiku55, gpt56luna")
    ap.add_argument("--run", type=int, required=True)
    ap.add_argument("--from", dest="src", required=True)
    ap.add_argument("--minutes", type=float, required=True, help="wall-clock minutes for the run")
    ap.add_argument("--credits", type=float, help="Kiro credits used by the run")
    ap.add_argument("--mode", default="full")
    ap.add_argument("--notes", default="")
    a = ap.parse_args(argv)
    scenario = a.scenario
    if not scenario:
        bm = REPO / "examples" / "evaluation" / "blind-map.json"
        scenario = json.loads(bm.read_text(encoding="utf-8")).get(a.case) if bm.exists() else None
    if not scenario:
        print("Give --scenario, or a --case listed in blind-map.json")
        return 2
    src = Path(a.src)
    if not (src / "evidence.json").exists():
        print(f"No evidence.json in {src}; the run did not finish.")
        return 2
    dest = REPO / "runs" / scenario / f"{a.model}-run{a.run}"
    if dest.exists():
        print(f"{dest} already exists; use a new --run number.")
        return 2
    dest.mkdir(parents=True)
    copied = [f for f in FILES if (src / f).exists() and shutil.copy(src / f, dest / f)]
    meta = {"scenario": scenario, "case": a.case, "model": a.model, "run": a.run, "mode": a.mode,
            "minutes": a.minutes, "credits": a.credits, "recorded_at": datetime.now(timezone.utc).isoformat(),
            "files": copied, "notes": a.notes}
    (dest / "meta.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    print(f"Recorded {scenario} {a.model} run {a.run} -> {dest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
