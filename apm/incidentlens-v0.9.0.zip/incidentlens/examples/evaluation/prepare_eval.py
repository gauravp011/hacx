"""Copy scenario inputs (never answer keys) into a clean evaluation workspace.

Usage:
    python examples/evaluation/prepare_eval.py --scenario all --dest ../incidentlens-eval
    python examples/evaluation/prepare_eval.py --scenario db-pool-exhaustion --dest ../incidentlens-eval --label case-01

Generates scenarios first if they are missing. With --blind (default) each scenario is copied under a neutral
folder name (case-01, case-02, ...) so the folder name doesn't hint at the answer; the mapping is written to
examples/evaluation/blind-map.json inside the repo, not in the workspace.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SCEN = REPO / "examples" / "scenarios"
GEN = REPO / "examples" / "generator"
INPUTS = ("logs", "deploys.json", "service_map.json")


def ensure_generated(ids: list[str]) -> None:
    missing = [i for i in ids if not (SCEN / i / "logs").exists()]
    if missing:
        subprocess.run([sys.executable, str(GEN / "generate_incident.py"), "--scenario", "all"], check=True)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenario", default="all")
    ap.add_argument("--dest", required=True)
    ap.add_argument("--no-blind", action="store_true", help="use scenario ids as folder names")
    a = ap.parse_args(argv)
    cfg = json.loads((GEN / "scenarios.json").read_text(encoding="utf-8"))
    ids = [s["id"] for s in cfg["scenarios"] if a.scenario in ("all", s["id"])]
    if not ids:
        print(f"Unknown scenario {a.scenario}")
        return 2
    ensure_generated(ids)
    dest = Path(a.dest).resolve()
    if REPO in dest.parents or dest == REPO:
        print("Choose a --dest OUTSIDE the repository so the agent cannot see answer keys.")
        return 2
    all_ids = [s["id"] for s in cfg["scenarios"]]
    mapping = {}
    for sid in ids:
        name = sid if a.no_blind else f"case-{all_ids.index(sid) + 1:02d}"
        target = dest / name
        if target.exists():
            shutil.rmtree(target)
        target.mkdir(parents=True)
        for item in INPUTS:
            src = SCEN / sid / item
            (shutil.copytree if src.is_dir() else shutil.copy)(src, target / item)
        symptom = next(s["summary"] for s in cfg["scenarios"] if s["id"] == sid)
        (target / "symptom.txt").write_text(symptom + "\n", encoding="utf-8")
        mapping[name] = sid
        print(f"{name}: inputs copied (no answer key) -> {target}")
    bm = REPO / "examples" / "evaluation" / "blind-map.json"
    old = json.loads(bm.read_text(encoding="utf-8")) if bm.exists() else {}
    old.update(mapping)
    bm.write_text(json.dumps(old, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"\nIn Kiro, open {dest}, then for each case run (new chat each time):\n"
          f"  /run-incident-analysis logs=case-01/logs deploys=case-01/deploys.json "
          f"service_map=case-01/service_map.json symptom=\"<contents of case-01/symptom.txt>\" "
          f"output_dir=case-01/incident-report")
    return 0


if __name__ == "__main__":
    sys.exit(main())
