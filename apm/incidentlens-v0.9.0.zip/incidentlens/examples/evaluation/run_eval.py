"""Score recorded runs against the hidden answer keys and write the scorecard.

Usage:
    python examples/evaluation/run_eval.py [--runs runs] [--out evidence]

Reads runs/<scenario>/<model>-run<N>/{evidence.json, evidence-check.json, meta.json} and
examples/scenarios/<scenario>/answer.json (regenerated if missing). Writes evidence/scorecard.md and
evidence/scorecard.json, broken down by model and by difficulty.

Metrics: top-1 / top-3 root-cause accuracy, service accuracy, trigger accuracy, evidence precision
(cited lines within +-5 line numbers of a key line or in a key causal cluster count as relevant),
red-herring rate, redaction recall (planted secrets absent from all outputs), evidence-check pass rate,
repeatability, minutes and credits per run, cost per correct RCA, host-scope accuracy (partial rollouts),
control-scenario pass (says insufficient evidence when nothing is wrong).
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SCEN = REPO / "examples" / "scenarios"
sys.path.insert(0, str(REPO / ".apm" / "skills" / "log-parser" / "scripts"))
from _common import template  # noqa: E402

_LINES: dict[str, dict[str, str]] = {}


def line_templates(scenario: str) -> dict[str, str]:
    """line_id -> service|template for a generated scenario (cached)."""
    if scenario not in _LINES:
        m = {}
        for f in (SCEN / scenario / "logs").glob("*.jsonl"):
            with open(f, encoding="utf-8") as fh:
                for raw in fh:
                    r = json.loads(raw)
                    m[r["line_id"]] = f"{r['service']}|{template(r['msg'])}"
        _LINES[scenario] = m
    return _LINES[scenario]


def lid_num(x: str) -> int:
    return int(re.sub(r"\D", "", x) or 0)


def load_answer(scenario: str) -> dict:
    p = SCEN / scenario / "answer.json"
    if not p.exists():
        subprocess.run([sys.executable, str(REPO / "examples" / "generator" / "generate_incident.py"),
                        "--scenario", scenario], check=True, capture_output=True)
    return json.loads(p.read_text(encoding="utf-8"))


def score_run(run_dir: Path, ans: dict) -> dict:
    ev = json.loads((run_dir / "evidence.json").read_text(encoding="utf-8"))
    chk_p = run_dir / "evidence-check.json"
    chk = json.loads(chk_p.read_text(encoding="utf-8")) if chk_p.exists() else {}
    meta_p = run_dir / "meta.json"
    meta = json.loads(meta_p.read_text(encoding="utf-8")) if meta_p.exists() else {}
    hyps = ev.get("hypotheses") or []
    top = hyps[0] if hyps else {}
    control = ans["root_cause_id"] == "NONE"
    if control:
        correct = ev.get("status") == "insufficient_evidence" or (
            top.get("root_cause_id") == "UNKNOWN" and top.get("confidence") == "low")
        top3 = correct
        service_ok = trigger_ok = correct
    else:
        correct = ev.get("status") == "ok" and top.get("root_cause_id") == ans["root_cause_id"]
        top3 = any(h.get("root_cause_id") == ans["root_cause_id"] for h in hyps[:3])
        service_ok = top.get("service") == ans["root_cause_service"]
        trig = set(top.get("related_event_ids") or [])
        trigger_ok = (not trig) if ans["trigger_event_id"] is None else ans["trigger_event_id"] in trig
    cited = top.get("evidence_line_ids") or []
    keys = [lid_num(k) for k in ans["key_evidence_line_ids"]]
    tpl = line_templates(ans["scenario"])
    key_tpls = {tpl.get(k) for k in ans["key_evidence_line_ids"] + (ans.get("supporting_line_ids") or [])}
    herr_tpls = {tpl.get(h) for h in ans.get("red_herrings") or []}
    relevant = [c for c in cited if any(abs(lid_num(c) - k) <= 5 for k in keys) or tpl.get(c) in key_tpls]
    herring_hit = any(tpl.get(c) in herr_tpls for c in cited)
    precision = (len(relevant) / len(cited)) if cited and keys else (1.0 if control and not cited else 0.0)
    outputs = "".join(p.read_text(encoding="utf-8", errors="replace") for p in run_dir.iterdir()
                      if p.is_file() and p.name != "meta.json")
    planted = ans.get("planted_secrets") or []
    leaked = [s["type"] for s in planted if s["value"] in outputs]
    host_ok = None
    if ans.get("affected_hosts"):
        host_ok = sorted(ev.get("affected_hosts") or []) == sorted(ans["affected_hosts"])
    return {
        "correct_top1": correct, "correct_top3": top3, "service_ok": service_ok, "trigger_ok": trigger_ok,
        "evidence_precision": round(precision, 2), "red_herring_cited": herring_hit,
        "redaction_recall": (len(planted) - len(leaked)) / len(planted) if planted else 1.0, "leaked": leaked,
        "evidence_check_passed": bool(chk.get("passed")), "unverified_claims": len(chk.get("unverified_claims", [])),
        "host_scope_ok": host_ok, "top_id": top.get("root_cause_id") or ev.get("status"),
        "minutes": meta.get("minutes"), "credits": meta.get("credits"),
    }


def pct(xs: list) -> str:
    xs = [x for x in xs if x is not None]
    return f"{100 * sum(bool(x) for x in xs) / len(xs):.0f}%" if xs else "–"


def avg(xs: list) -> float | None:
    xs = [x for x in xs if isinstance(x, (int, float))]
    return round(sum(xs) / len(xs), 2) if xs else None


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs", default=str(REPO / "runs"))
    ap.add_argument("--out", default=str(REPO / "evidence"))
    a = ap.parse_args(argv)
    runs_root, out = Path(a.runs), Path(a.out)
    rows = []
    for ev_path in sorted(runs_root.glob("*/*/evidence.json")):
        run_dir = ev_path.parent
        scenario = run_dir.parent.name
        m = re.match(r"(.+)-run(\d+)$", run_dir.name)
        if not m:
            continue
        ans = load_answer(scenario)
        r = score_run(run_dir, ans)
        r.update({"scenario": scenario, "model": m.group(1), "run": int(m.group(2)),
                  "difficulty": ans["difficulty"], "expected": ans["root_cause_id"]})
        rows.append(r)
    if not rows:
        print(f"No runs found under {runs_root}. Record runs with record_run.py first.")
        return 1

    def block(sel: list[dict]) -> dict:
        by_s = defaultdict(list)
        for r in sel:
            by_s[r["scenario"]].append(r["top_id"])
        rep = [len(set(v)) == 1 for v in by_s.values() if len(v) > 1]
        correct = sum(r["correct_top1"] for r in sel)
        credits = [r["credits"] for r in sel if r["credits"] is not None]
        return {"runs": len(sel), "top1": pct([r["correct_top1"] for r in sel]),
                "top3": pct([r["correct_top3"] for r in sel]), "service": pct([r["service_ok"] for r in sel]),
                "trigger": pct([r["trigger_ok"] for r in sel]),
                "evidence_precision": avg([r["evidence_precision"] for r in sel]),
                "red_herring_rate": pct([r["red_herring_cited"] for r in sel]),
                "redaction_recall": avg([r["redaction_recall"] for r in sel]),
                "evidence_check_pass": pct([r["evidence_check_passed"] for r in sel]),
                "host_scope": pct([r["host_scope_ok"] for r in sel]),
                "repeatability": pct(rep) if rep else "–",
                "avg_minutes": avg([r["minutes"] for r in sel]), "avg_credits": avg(credits),
                "credits_per_correct": round(sum(credits) / correct, 2) if credits and correct else None}

    models = sorted({r["model"] for r in rows})
    summary = {"by_model": {m: block([r for r in rows if r["model"] == m]) for m in models},
               "by_difficulty": {d: block([r for r in rows if r["difficulty"] == d])
                                 for d in sorted({r["difficulty"] for r in rows})},
               "runs": rows}
    baseline = REPO / "examples" / "evaluation" / "manual_baseline.md"
    base_rows = []
    if baseline.exists():
        for line in baseline.read_text(encoding="utf-8").splitlines():
            cells = [c.strip() for c in line.strip("|").split("|")]
            if len(cells) >= 3 and re.match(r"^\d+(\.\d+)?$", cells[1]):
                base_rows.append({"scenario": cells[0], "minutes": float(cells[1]), "correct": cells[2]})
    summary["manual_baseline"] = base_rows
    out.mkdir(parents=True, exist_ok=True)
    (out / "scorecard.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    cols = ["runs", "top1", "top3", "service", "trigger", "evidence_precision", "red_herring_rate",
            "redaction_recall", "evidence_check_pass", "host_scope", "repeatability", "avg_minutes", "avg_credits",
            "credits_per_correct"]
    md = ["# IncidentLens scorecard", "",
          "Generated by `examples/evaluation/run_eval.py` from recorded runs in `runs/`. Synthetic scenarios with hidden answer keys.", "",
          "## By model", "", "| Model | " + " | ".join(cols) + " |", "|---" * (len(cols) + 1) + "|"]
    md += [f"| {m} | " + " | ".join(str(v.get(c) if v.get(c) is not None else "–") for c in cols) + " |"
           for m, v in summary["by_model"].items()]
    md += ["", "## By difficulty", "", "| Difficulty | " + " | ".join(cols) + " |", "|---" * (len(cols) + 1) + "|"]
    md += [f"| {d} | " + " | ".join(str(v.get(c) if v.get(c) is not None else "–") for c in cols) + " |"
           for d, v in summary["by_difficulty"].items()]
    md += ["", "## Runs", "", "| Scenario | Model | Run | Expected | Got | Correct | Service | Trigger | Evidence check | Minutes | Credits |",
           "|---|---|---|---|---|---|---|---|---|---|---|"]
    md += [f"| {r['scenario']} | {r['model']} | {r['run']} | {r['expected']} | {r['top_id']} | "
           f"{'yes' if r['correct_top1'] else 'no'} | {'yes' if r['service_ok'] else 'no'} | "
           f"{'yes' if r['trigger_ok'] else 'no'} | {'pass' if r['evidence_check_passed'] else 'fail'} | "
           f"{r['minutes'] if r['minutes'] is not None else '–'} | {r['credits'] if r['credits'] is not None else '–'} |"
           for r in sorted(rows, key=lambda r: (r["scenario"], r["model"], r["run"]))]
    if base_rows:
        md += ["", "## Manual baseline", "", "| Scenario | Minutes | Correct |", "|---|---|---|"]
        md += [f"| {b['scenario']} | {b['minutes']} | {b['correct']} |" for b in base_rows]
    md += ["", "Metric notes: evidence precision counts cited lines that are within ±5 line IDs of a key evidence line or share "
           "a key line's message template (same causal or symptom cluster); redaction recall = planted fake secrets absent from all outputs; "
           "control scenario passes when the run reports insufficient evidence."]
    (out / "scorecard.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(f"Scored {len(rows)} runs -> {out / 'scorecard.md'}")
    for m, v in summary["by_model"].items():
        print(f"  {m}: top-1 {v['top1']}, service {v['service']}, evidence check {v['evidence_check_pass']}, "
              f"redaction recall {v['redaction_recall']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
