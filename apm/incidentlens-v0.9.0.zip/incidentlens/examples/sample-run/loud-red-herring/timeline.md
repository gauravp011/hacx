# Incident timeline

```mermaid
timeline
    title Incident timeline (UTC, 20 Nov 2026)
    09:30 : 429 rate limiting of partner-7 begins on /api/products (unrelated) [L005901]
    09:50 : D071 config change inventory-service db.pool.max_size 40 -> 4
    09:52 : First DB pool timeout in inventory-service [L013471]
    09:53 : First failed order reservation in order-service [L013812]
    09:54 : First checkout 503 at api-gateway [L014292]
    10:10 : Payment provider retry blip (unrelated) [L019980]
    10:29 : Errors still ongoing at end of logs [L027030]
```
