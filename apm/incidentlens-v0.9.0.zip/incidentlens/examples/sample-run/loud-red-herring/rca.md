# Root cause analysis

**#1 DB_POOL_EXHAUSTION in `inventory-service` — confidence high.** Config change D071 (09:50 UTC) reduced the inventory-service DB pool from 40 to 4. From 09:52 requests timed out waiting for a connection with the pool full [L013471], order reservations failed from 09:53 [L013812] and checkout returned 503 from 09:54 [L014292]. The errors continue to the end of the window [L027030].

## Evidence
- `L013471` 09:52:00 inventory-service ERROR Timeout acquiring DB connection after 5000ms (pool active=4/4)
- `L027030` 10:29:03 inventory-service ERROR Timeout acquiring DB connection after 5049ms (pool active=4/4)
- `L013812` 09:53:00 order-service ERROR Reservation failed for order 163410: inventory-service timeout
- `L014292` 09:54:20 api-gateway ERROR POST /api/checkout 503 upstream order-service error

## Other hypotheses
- #2 DEPENDENCY_LATENCY (low): a slow inventory-db could also fill the pool, but there are no DB latency or slow-query messages, and the timing matches D071 [L013471].

## Red herrings considered
- api-gateway 429 rate limiting of client partner-7 [L005901]: the loudest cluster, but it started 22 minutes earlier on /api/products and is not on the checkout path.
- payment-service retry blip [L019980]: five warnings in one minute, no downstream effect.

## Five whys
1. Checkout failed because order-service failed [L014292].
2. order-service failed because stock reservations timed out [L013812].
3. Reservations timed out because inventory-service waited 5 s for DB connections, pool full at 4/4 [L013471].
4. The pool was full because D071 set max_size to 4, two minutes before the first timeout [L013471].
5. The change shipped without a load check or a pool wait-time alert.

## Open questions
- Was D071 intended for a different environment?
