"""Synthetic incident generator for IncidentLens.

Data-driven: systems and scenarios live in scenarios.json, so a new scenario needs no code.
Deterministic: one random.Random(seed) per scenario, fixed base time, no wall-clock reads.

Usage:
    python examples/generator/generate_incident.py --scenario all
    python examples/generator/generate_incident.py --scenario db-pool-exhaustion --out examples/scenarios
    python examples/generator/generate_incident.py --scenario all --check   # verify against scenarios.lock.json
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONFIG = HERE / "scenarios.json"
LOCK = HERE / "scenarios.lock.json"
DEFAULT_OUT = HERE.parent / "scenarios"
BASE_TIME = datetime(2026, 11, 20, 9, 0, 0, tzinfo=timezone.utc)

SECRET_CATEGORIES = ["EMAIL", "IPV4", "IPV6", "BEARER_TOKEN", "JWT", "KEY_VALUE_SECRET",
                     "HEX_SECRET", "BASE64_SECRET", "CARD_NUMBER"]
TEST_CARDS = ["4111111111111111", "5555555555554444", "378282246310005", "4012888888881881"]
SECRET_MESSAGES = {
    "EMAIL": "Notification queued for {s}",
    "IPV4": "Client {s} exceeded soft rate limit",
    "IPV6": "Health probe from {s} accepted",
    "BEARER_TOKEN": "Calling downstream with Authorization: {s}",
    "JWT": "Session validated, token={s}",
    "KEY_VALUE_SECRET": "Connecting with user=svc_app {s}",
    "HEX_SECRET": "Loaded signing key {s}",
    "BASE64_SECRET": "Decrypted config blob {s}",
    "CARD_NUMBER": "Card {s} tokenised for checkout",
}


def iso(t: datetime) -> str:
    """Format a UTC datetime as ISO-8601 with milliseconds and Z."""
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond // 1000:03d}Z"


def make_secret(cat: str, rng: random.Random) -> str:
    """Return an obviously fake secret value for a redaction category."""
    hx = lambda n: "".join(rng.choice("0123456789abcdef") for _ in range(n))  # noqa: E731
    if cat == "EMAIL":
        return f"{rng.choice(['jane.doe', 'sam.lee', 'ops.team', 'a.kumar'])}@example.test"
    if cat == "IPV4":
        return rng.choice([f"10.{rng.randint(0, 255)}.{rng.randint(0, 255)}.{rng.randint(1, 254)}",
                           f"192.168.{rng.randint(0, 255)}.{rng.randint(1, 254)}"])
    if cat == "IPV6":
        return f"fd12:3456:789a::{hx(4)}"
    if cat == "BEARER_TOKEN":
        return f"Bearer FAKE-tok-{hx(16)}"
    if cat == "JWT":
        return f"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJGQUtFLXVzZXIifQ.FAKE{hx(20)}"
    if cat == "KEY_VALUE_SECRET":
        return rng.choice([f"password=FAKE-{hx(10)}", f"api_key=FAKE-{hx(16)}"])
    if cat == "HEX_SECRET":
        return hx(40)
    if cat == "BASE64_SECRET":
        return base64.b64encode(f"FAKE-secret-{hx(24)}".encode()).decode()
    if cat == "CARD_NUMBER":
        return rng.choice(TEST_CARDS)
    raise ValueError(cat)


class Emitter:
    """Collects raw log records; line_ids are assigned later in time order."""

    def __init__(self, rng: random.Random, system: dict):
        self.rng = rng
        self.system = system
        self.records: list[dict] = []

    def fill(self, template: str, progress: float, ramp: tuple[float, float] | None, lat: int | None = None) -> str:
        r = self.rng
        values = {
            "lat": lat if lat is not None else max(4, int(r.gauss(85, 25))), "n": r.randint(1, 99), "n2": r.randint(1, 3),
            "big": r.randint(100000, 999999), "sku": r.randint(1000, 9999), "ms": r.randint(5000, 5100),
            "t": round(r.uniform(2.0, 6.5), 1), "sn": f"{r.randint(1, 40):03d}",
            "ramp": int(ramp[0] + (ramp[1] - ramp[0]) * progress) if ramp else 0,
        }
        return template.format(**values)

    def add(self, t: datetime, service: str, level: str, msg: str, host: str,
            status: int | None = None, latency: int | None = None, tag: str | None = None) -> None:
        self.records.append({"ts": t, "service": service, "host": host, "level": level,
                             "trace_id": f"{self.rng.getrandbits(32):08x}", "msg": msg,
                             "http_status": status, "latency_ms": latency, "_tag": tag})

    def stream(self, s: dict, duration: int) -> None:
        """Emit a stream of events with a linearly ramping rate (events/min), optionally periodic bursts."""
        r = self.rng
        hosts = s.get("hosts") or self.system["services"][s["service"]]["hosts"]
        start, end = s.get("start", 0), min(s.get("end", duration), duration)
        windows = [(start, end)]
        if "every_min" in s:
            windows, m = [], start
            while m < end:
                windows.append((m, min(end, m + s.get("burst_min", 1))))
                m += s["every_min"]
        total = max(1e-9, end - start)
        first = True
        for w0, w1 in windows:
            sec = int(w0 * 60)
            while sec < int(w1 * 60):
                progress = (sec / 60 - start) / total
                rate = s.get("rate_from", s.get("rate", 1)) + (
                    s.get("rate_to", s.get("rate_from", s.get("rate", 1))) - s.get("rate_from", s.get("rate", 1))) * progress
                expected = rate / 60.0
                count = int(expected) + (1 if r.random() < expected - int(expected) else 0)
                if first and sec == int(start * 60) and s.get("tag") in ("causal", "symptom") and count == 0:
                    count = 1  # every causal/symptom stream emits at its exact onset
                for _ in range(count):
                    t = BASE_TIME + timedelta(seconds=sec, milliseconds=r.randint(0, 999))
                    tag = s.get("tag")
                    if first and tag in ("causal", "symptom", "red_herring", "causal_support", "symptom_support"):
                        tag = f"first_{tag}"
                    first = False
                    lat = s.get("latency") or (max(4, int(r.gauss(85, 25))) if s.get("status") == 200 else None)
                    self.add(t, s["service"], s["level"], self.fill(r.choice(s["msgs"]), progress, s.get("ramp"), lat),
                             r.choice(hosts), s.get("status"), lat, tag)
                sec += 1


def build(scenario: dict, systems: dict) -> tuple[dict[str, list[dict]], list[dict], dict, dict]:
    """Generate one scenario. Returns (lines_by_service, deploys, service_map, answer)."""
    rng = random.Random(scenario["seed"])
    system = systems[scenario["system"]]
    duration = scenario.get("duration_min", 90)
    em = Emitter(rng, system)

    for name, svc in system["services"].items():
        for bg in svc["background"]:
            em.stream({"service": name, **bg, "start": 0, "end": duration}, duration)
    for s in scenario.get("streams", []):
        em.stream(s, duration)

    planted = []
    for i, cat in enumerate(SECRET_CATEGORIES):
        value = make_secret(cat, rng)
        svc = rng.choice(list(system["services"]))
        t = BASE_TIME + timedelta(minutes=3 + i * (duration - 6) / len(SECRET_CATEGORIES), seconds=rng.randint(0, 59))
        em.add(t, svc, "INFO", SECRET_MESSAGES[cat].format(s=value), rng.choice(system["services"][svc]["hosts"]),
               tag=f"secret|{cat}|{value}")

    em.records.sort(key=lambda r: (r["ts"], r["service"], r["host"], r["msg"]))
    by_service: dict[str, list[dict]] = {name: [] for name in system["services"]}
    firsts: dict[str, list[str]] = {}
    causal_ids: list[str] = []
    for n, rec in enumerate(em.records, start=1):
        lid = f"L{n:06d}"
        tag = rec.pop("_tag")
        if tag and tag.startswith("secret|"):
            _, cat, value = tag.split("|", 2)
            planted.append({"line_id": lid, "type": cat, "value": value})
        elif tag:
            kind = tag.replace("first_", "")
            if tag.startswith("first_"):
                firsts.setdefault(kind, []).append(lid)
            if kind == "causal":
                causal_ids.append(lid)
        line = {"line_id": lid, "ts": iso(rec["ts"])}
        line.update({k: v for k, v in rec.items() if k != "ts" and v is not None})
        by_service[rec["service"]].append(line)

    key_ids: list[str] = []
    if causal_ids:
        key_ids = [firsts["causal"][0], causal_ids[int(len(causal_ids) * 0.6)]]
        key_ids += firsts.get("symptom", [])[:1]
    deploys = []
    for d in scenario.get("deploys", []):
        ev = {k: v for k, v in d.items() if k != "at_min"}
        ev["ts"] = iso(BASE_TIME + timedelta(minutes=d["at_min"]))[:19] + "Z"
        deploys.append({k: ev[k] for k in ("event_id", "ts", "service", "version", "change_type", "details")})
    a = scenario["answer"]
    fault_start = None
    if a["root_cause_id"] != "NONE":
        if a.get("trigger_event_id"):
            fault_start = next(d["ts"] for d in deploys if d["event_id"] == a["trigger_event_id"])
        else:
            fault_start = iso(BASE_TIME + timedelta(minutes=min(s["start"] for s in scenario["streams"]
                                                                  if s.get("tag") == "causal")))[:19] + "Z"
    answer = {
        "scenario": scenario["id"], "seed": scenario["seed"], "system": scenario["system"],
        "difficulty": scenario["difficulty"], "tier": scenario["tier"],
        "root_cause_id": a["root_cause_id"], "root_cause_service": a.get("root_cause_service"),
        "trigger_event_id": a.get("trigger_event_id"), "fault_start": fault_start,
        "expected_status": "insufficient_evidence" if a["root_cause_id"] == "NONE" else "ok",
        "affected_hosts": a.get("affected_hosts"),
        "key_evidence_line_ids": key_ids,
        "supporting_line_ids": firsts.get("causal_support", []) + firsts.get("symptom_support", []),
        "red_herrings": firsts.get("red_herring", []),
        "planted_secrets": planted,
    }
    return by_service, deploys, system["service_map"], answer


def write(scenario_id: str, out_root: Path, built: tuple) -> list[Path]:
    """Write one scenario folder. Returns written file paths."""
    by_service, deploys, smap, answer = built
    out = out_root / scenario_id
    (out / "logs").mkdir(parents=True, exist_ok=True)
    paths = []
    for svc, lines in by_service.items():
        p = out / "logs" / f"{svc}.jsonl"
        with open(p, "w", encoding="utf-8", newline="\n") as fh:
            for line in lines:
                fh.write(json.dumps(line, separators=(",", ":")) + "\n")
        paths.append(p)
    for name, obj in (("deploys.json", deploys), ("service_map.json", smap), ("answer.json", answer)):
        p = out / name
        p.write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8", newline="\n")
        paths.append(p)
    return paths


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenario", default="all", help="scenario id or 'all'")
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    ap.add_argument("--check", action="store_true", help="verify output hashes against scenarios.lock.json")
    ap.add_argument("--write-lock", action="store_true", help="(maintainer) rewrite scenarios.lock.json")
    args = ap.parse_args(argv)

    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    chosen = [s for s in cfg["scenarios"] if args.scenario in ("all", s["id"])]
    if not chosen:
        print(f"Unknown scenario '{args.scenario}'. Known: {[s['id'] for s in cfg['scenarios']]}", file=sys.stderr)
        return 2
    out_root = Path(args.out)
    lock = json.loads(LOCK.read_text(encoding="utf-8")) if LOCK.exists() else {}
    new_lock, mismatches = dict(lock), []
    for sc in chosen:
        paths = write(sc["id"], out_root, build(sc, cfg["systems"]))
        lines = sum(1 for p in paths if p.suffix == ".jsonl" for _ in open(p, encoding="utf-8"))
        hashes = {p.relative_to(out_root / sc["id"]).as_posix(): sha256(p) for p in paths}
        new_lock[sc["id"]] = hashes
        if args.check and lock.get(sc["id"]) != hashes:
            mismatches.append(sc["id"])
        print(f"{sc['id']:<24} {lines:>6} lines  -> {out_root / sc['id']}")
    if args.write_lock:
        LOCK.write_text(json.dumps(new_lock, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
        print(f"Lock file written: {LOCK}")
    if args.check:
        if mismatches:
            print(f"MISMATCH vs lock file: {mismatches}", file=sys.stderr)
            return 1
        print("All generated files match scenarios.lock.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
