import json

import pytest

from conftest import REPO, SKILLS, run

CV = SKILLS / "log-parser" / "scripts" / "convert_logs.py"
FX = REPO / "tests" / "fixtures" / "formats"
CASES = {
    "app-iso.log": ("plain:iso", 3, {"ERROR", "WARN", "INFO"}),
    "spring.log": ("plain:log4j", 3, {"ERROR", "WARN", "INFO"}),
    "worker.py.log": ("plain:python", 2, {"ERROR", "INFO"}),
    "gateway-syslog.log": ("plain:syslog3164", 3, {"FATAL", "ERROR", "INFO"}),
    "rfc5424.log": ("plain:syslog5424", 2, {"ERROR", "INFO"}),
    "access.log": ("plain:access", 3, {"ERROR", "WARN", "INFO"}),
    "cloudwatch.json": ("cloudwatch", 2, {"ERROR", "WARN"}),
    "datadog.json": ("datadog", 2, {"ERROR", "INFO"}),
    "ecs.ndjson": ("ecs", 2, {"ERROR", "INFO"}),
    "export.csv": ("csv", 2, {"ERROR", "INFO"}),
}


def rows(out):
    return [json.loads(x) for f in sorted(out.glob("*.jsonl")) for x in f.read_text().splitlines()]


@pytest.mark.parametrize("name,expect", CASES.items())
def test_formats(tmp_path, name, expect):
    fmt, n, levels = expect
    out = tmp_path / "logs"
    r = run(CV, FX / name, out, "--year", "2026")
    assert r.returncode == 0, r.stderr
    rep = json.loads((tmp_path / "conversion-report.json").read_text())
    assert rep["files"][0]["format"] == fmt
    got = rows(out)
    assert len(got) == n
    assert {x["level"] for x in got} == levels
    assert sorted(x["line_id"] for x in got) == [f"L{i:06d}" for i in range(1, n + 1)]
    assert all(x["ts"].startswith("2026-11-20T09:3") for x in got)


def test_stack_traces_joined(tmp_path):
    run(CV, FX / "spring.log", tmp_path / "logs")
    err = next(x for x in rows(tmp_path / "logs") if x["level"] == "ERROR")
    assert "IllegalStateException" in err["msg"] and " | at " in err["msg"]


def test_unknown_format_exit_3_then_mapping(tmp_path):
    r = run(CV, FX / "custom-device.log", tmp_path / "a")
    assert r.returncode == 3 and "UNKNOWN FORMAT" in r.stderr
    r = run(CV, FX / "custom-device.log", tmp_path / "b", "--map", FX / "custom-device.map.json")
    assert r.returncode == 0
    got = rows(tmp_path / "b")
    assert {x["service"] for x in got} == {"decoder", "uplink"} and {x["level"] for x in got} == {"ERROR", "INFO"}


def test_converted_logs_flow_through_pipeline(tmp_path):
    r = run(SKILLS / "run-incident-analysis" / "scripts" / "prepare_incident.py", "--logs", FX / "datadog.json",
            "--output-dir", tmp_path / "rep")
    assert r.returncode == 0, r.stdout
    assert not (tmp_path / "rep" / "work" / "converted").exists(), "unredacted conversion must be deleted"
    assert (tmp_path / "rep" / "work" / "summary.json").exists()
