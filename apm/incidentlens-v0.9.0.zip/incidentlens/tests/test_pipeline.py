import ast
import json
import shutil
import sys
from pathlib import Path

from conftest import REPO, SKILLS, run

SAMPLE = REPO / "examples" / "sample-run" / "loud-red-herring"


def test_finalize_builds_offline_report(prepared, tmp_path):
    o = tmp_path / "rep"
    shutil.copytree(prepared["loud-red-herring"], o)
    for f in ("evidence.json", "rca.md", "postmortem.md", "timeline.md"):
        shutil.copy(SAMPLE / f, o / f)
    r = run(SKILLS / "run-incident-analysis" / "scripts" / "finalize_incident.py", "--output-dir", o)
    assert r.returncode == 0, r.stdout
    html = (o / "report.html").read_text()
    assert "http://" not in html and "https://" not in html and "<script" not in html
    ev = json.loads((o / "evidence.json").read_text())
    for i in ev["hypotheses"][0]["evidence_line_ids"]:
        assert i in html
    assert json.loads((o / "evidence-check.json").read_text())["passed"]


def test_prepare_stops_on_missing_logs(tmp_path):
    r = run(SKILLS / "run-incident-analysis" / "scripts" / "prepare_incident.py", "--logs", tmp_path / "missing",
            "--output-dir", tmp_path / "o")
    assert r.returncode != 0 and "STOPPED" in r.stdout


def test_finalize_stops_without_outputs(tmp_path):
    r = run(SKILLS / "run-incident-analysis" / "scripts" / "finalize_incident.py", "--output-dir", tmp_path)
    assert r.returncode != 0 and "STOPPED" in r.stdout


def test_doctor_passes():
    r = run(SKILLS / "run-incident-analysis" / "scripts" / "doctor.py", "--logs", REPO / "tests" / "fixtures" / "formats")
    assert r.returncode == 0, r.stdout


def test_shipped_code_is_stdlib_only():
    allowed = set(sys.stdlib_module_names) | {"__future__", "_common", "redact", "convert_logs"}
    for py in (REPO / ".apm").rglob("*.py"):
        tree = ast.parse(py.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            names = [a.name for a in node.names] if isinstance(node, ast.Import) else \
                [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
            for n in names:
                assert n.split(".")[0] in allowed, f"{py.name} imports {n}"


def test_skill_frontmatter():
    for skill in (REPO / ".apm" / "skills").iterdir():
        text = (skill / "SKILL.md").read_text(encoding="utf-8")
        assert text.startswith("---\n"), skill.name
        head = text.split("---")[1]
        assert f"name: {skill.name}\n" in head
        desc = next(l for l in head.splitlines() if l.startswith("description:"))
        assert desc.split(":", 1)[1].strip().startswith("Use "), skill.name
        assert len(desc) <= 1100 and len(text.splitlines()) < 500


def test_skills_do_not_leak_scenario_answers():
    cfg = json.loads((REPO / "examples" / "generator" / "scenarios.json").read_text())
    banned = {d["event_id"] for s in cfg["scenarios"] for d in s.get("deploys", [])} | {"partner-7", "gw-02", "0x1F"}
    for f in (REPO / ".apm").rglob("*.md"):
        text = f.read_text(encoding="utf-8")
        for b in banned:
            assert b not in text, f"{f.relative_to(REPO)} mentions {b}"
