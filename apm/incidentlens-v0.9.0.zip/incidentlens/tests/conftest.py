"""Shared fixtures: generated scenarios and a prepared (redacted + parsed) output folder per scenario."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
SKILLS = REPO / ".apm" / "skills"
SCEN = REPO / "examples" / "scenarios"
CONFIG = json.loads((REPO / "examples" / "generator" / "scenarios.json").read_text(encoding="utf-8"))
SCENARIO_IDS = [s["id"] for s in CONFIG["scenarios"]]
PY = sys.executable


def run(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess:
    return subprocess.run([PY, *map(str, args)], capture_output=True, text=True, cwd=cwd, encoding="utf-8")


@pytest.fixture(scope="session")
def scenarios() -> Path:
    if not all((SCEN / s / "answer.json").exists() for s in SCENARIO_IDS):
        r = run(REPO / "examples" / "generator" / "generate_incident.py", "--scenario", "all")
        assert r.returncode == 0, r.stderr
    return SCEN


def answer(sid: str) -> dict:
    return json.loads((SCEN / sid / "answer.json").read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def prepared(scenarios, tmp_path_factory) -> dict[str, Path]:
    """Run prepare_incident.py once per scenario; return {scenario: output_dir}."""
    root = tmp_path_factory.mktemp("prepared")
    out = {}
    for sid in SCENARIO_IDS:
        o = root / sid
        r = run(SKILLS / "run-incident-analysis" / "scripts" / "prepare_incident.py", "--logs", scenarios / sid / "logs",
                "--deploys", scenarios / sid / "deploys.json", "--service-map", scenarios / sid / "service_map.json",
                "--output-dir", o)
        assert r.returncode == 0, r.stdout + r.stderr
        out[sid] = o
    return out
