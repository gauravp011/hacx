import hashlib
import json

from conftest import REPO, SCENARIO_IDS, answer, run

LEVELS = {"TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"}


def _lines(scen, sid):
    for f in sorted((scen / sid / "logs").glob("*.jsonl")):
        with open(f, encoding="utf-8") as fh:
            for raw in fh:
                yield json.loads(raw)


def test_lock_file_matches(scenarios):
    r = run(REPO / "examples" / "generator" / "generate_incident.py", "--scenario", "all", "--check")
    assert r.returncode == 0, r.stdout + r.stderr


def test_same_seed_identical_output(tmp_path):
    for out in ("a", "b"):
        r = run(REPO / "examples" / "generator" / "generate_incident.py", "--scenario", "cert-expiry", "--out", tmp_path / out)
        assert r.returncode == 0
    h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()  # noqa: E731
    for f in (tmp_path / "a" / "cert-expiry").rglob("*.*"):
        assert h(f) == h(tmp_path / "b" / "cert-expiry" / f.relative_to(tmp_path / "a" / "cert-expiry"))


def test_line_ids_unique_and_time_ordered(scenarios):
    for sid in SCENARIO_IDS:
        rows = sorted(_lines(scenarios, sid), key=lambda r: r["line_id"])
        ids = [r["line_id"] for r in rows]
        assert len(ids) == len(set(ids)), sid
        ts = [r["ts"] for r in rows]
        assert ts == sorted(ts), f"{sid}: line_ids not in time order"
        assert 15000 <= len(rows) <= 40000, (sid, len(rows))
        assert {r["level"] for r in rows} <= LEVELS


def test_answer_keys_reference_real_lines(scenarios):
    for sid in SCENARIO_IDS:
        a = answer(sid)
        ids = {r["line_id"] for r in _lines(scenarios, sid)}
        for k in a["key_evidence_line_ids"] + a["red_herrings"] + a.get("supporting_line_ids", []):
            assert k in ids, (sid, k)
        assert len(a["red_herrings"]) >= 2, sid
        if a["root_cause_id"] == "NONE":
            assert a["key_evidence_line_ids"] == [] and a["expected_status"] == "insufficient_evidence"
        else:
            assert len(a["key_evidence_line_ids"]) >= 2, sid


def test_planted_secrets_cover_every_category(scenarios):
    cats = {"EMAIL", "IPV4", "IPV6", "BEARER_TOKEN", "JWT", "KEY_VALUE_SECRET", "HEX_SECRET", "BASE64_SECRET", "CARD_NUMBER"}
    for sid in SCENARIO_IDS:
        a = answer(sid)
        assert {s["type"] for s in a["planted_secrets"]} == cats, sid
        text = {r["line_id"]: r["msg"] for r in _lines(scenarios, sid)}
        for s in a["planted_secrets"]:
            assert s["value"] in text[s["line_id"]]
            assert "FAKE" in s["value"] or "example.test" in s["value"] or s["type"] in (
                "IPV4", "IPV6", "HEX_SECRET", "BASE64_SECRET", "CARD_NUMBER")


def test_trigger_events_exist(scenarios):
    for sid in SCENARIO_IDS:
        a = answer(sid)
        deploys = json.loads((scenarios / sid / "deploys.json").read_text(encoding="utf-8"))
        if a["trigger_event_id"]:
            assert a["trigger_event_id"] in {d["event_id"] for d in deploys}
