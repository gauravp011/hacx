import json
import sys
from datetime import datetime, timedelta

from conftest import SCENARIO_IDS, SKILLS, answer, run

LP = SKILLS / "log-parser" / "scripts"
sys.path.insert(0, str(LP))
from _common import load_service_map  # noqa: E402


def summary(o):
    return json.loads((o / "work" / "summary.json").read_text(encoding="utf-8"))


def t(ts):
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def test_causal_cluster_is_notable_and_after_fault(prepared):
    for sid in SCENARIO_IDS:
        a = answer(sid)
        if a["root_cause_id"] == "NONE":
            continue
        clusters = json.loads((prepared[sid] / "work" / "clusters.json").read_text())
        first_key = a["key_evidence_line_ids"][0]
        hit = [c for c in clusters if c["kind"] == "notable" and c["service"] == a["root_cause_service"]
               and c["first_seen"] >= a["fault_start"][:19]]
        assert hit, sid
        assert any(first_key in c["samples"] for c in clusters), (sid, first_key)


def test_root_service_anomaly_precedes_its_callers(prepared):
    for sid in SCENARIO_IDS:
        a = answer(sid)
        if a["root_cause_id"] == "NONE":
            continue
        s = summary(prepared[sid])
        info = {x["service"]: x for x in s["services"]}
        root = info[a["root_cause_service"]]
        onset = root["first_notable_error"] or root["first_anomaly"]
        callers = [k for k, v in s["service_map"].items() if a["root_cause_service"] in v]
        for c in callers:
            other = info.get(c, {}).get("first_notable_error")
            if other and other >= a["fault_start"][:19]:
                assert onset[:16] <= other[:16], (sid, c)


def test_nearby_change_found(prepared):
    for sid in SCENARIO_IDS:
        a = answer(sid)
        if not a["trigger_event_id"]:
            continue
        s = summary(prepared[sid])
        near_cluster = any(a["trigger_event_id"] in c["nearby_changes"] for c in s["notable_clusters"]
                           if c["service"] == a["root_cause_service"])
        near_surge = any(a["trigger_event_id"] in (x.get("changes_before_volume_surge") or [])
                         for x in s["services"] if x["service"] == a["root_cause_service"])
        assert near_cluster or near_surge, sid


def test_partial_rollout_hosts_detected(prepared):
    s = summary(prepared["fleet-firmware-crash"])
    gw = [c for c in s["notable_clusters"] if c["service"] == "edge-gateway" and c["level"] == "ERROR"]
    assert gw and gw[0]["only_on_hosts"] == answer("fleet-firmware-crash")["affected_hosts"]


def test_volume_surge_detected_for_debug_flood(prepared):
    s = summary(prepared["disk-full"])
    inv = next(x for x in s["services"] if x["service"] == "inventory-service")
    assert inv["volume_anomaly_onset"] and inv["volume_anomaly_onset"] < "2026-11-20T10:02"


def test_loudest_is_not_first_in_hard_case(prepared):
    s = summary(prepared["loud-red-herring"])
    assert s["services_by_error_volume"][0] == "api-gateway"


def test_summary_is_compact(prepared):
    for sid in SCENARIO_IDS:
        n = len((prepared[sid] / "work" / "summary.json").read_text().splitlines())
        assert n < 200, (sid, n)


def test_get_lines_by_ids_range_around_cluster(prepared):
    o = prepared["db-pool-exhaustion"]
    k = answer("db-pool-exhaustion")["key_evidence_line_ids"][0]
    r = run(LP / "get_lines.py", o, "--ids", k)
    assert r.returncode == 0 and r.stdout.startswith(k)
    n = int(k[1:])
    r = run(LP / "get_lines.py", o, "--range", f"L{n-2:06d}:L{n+2:06d}")
    assert len(r.stdout.splitlines()) == 5
    r = run(LP / "get_lines.py", o, "--around", k, "--n", "3")
    assert len(r.stdout.splitlines()) == 7
    r = run(LP / "get_lines.py", o, "--cluster", "C001")
    assert r.returncode == 0 and r.stdout


def test_refuses_unredacted(tmp_path, scenarios):
    out = tmp_path / "o"
    (out / "work" / "redacted").mkdir(parents=True)
    for f in (scenarios / "cert-expiry" / "logs").glob("*.jsonl"):
        (out / "work" / "redacted" / f.name).write_text(f.read_text())
    r = run(LP / "parse_logs.py", out)
    assert r.returncode != 0 and "REFUSING" in (r.stdout + r.stderr)


def _mini(tmp_path, lines):
    out = tmp_path / "o"
    (out / "work" / "redacted").mkdir(parents=True)
    (out / "redaction-report.json").write_text("{}")
    (out / "work" / "redacted" / "svc.jsonl").write_text("\n".join(lines) + "\n")
    return out


def test_corrupted_lines_over_threshold_fail(tmp_path):
    good = [json.dumps({"line_id": f"L{i:06d}", "ts": "2026-11-20T09:00:00Z", "service": "s", "level": "INFO", "msg": "x"})
            for i in range(1, 10)]
    out = _mini(tmp_path, good + ["{broken", "not json at all"])
    r = run(LP / "parse_logs.py", out)
    assert r.returncode != 0 and "corrupted" in (r.stdout + r.stderr).lower()


def test_empty_time_window_fails(tmp_path):
    good = [json.dumps({"line_id": "L000001", "ts": "2026-11-20T09:00:00Z", "service": "s", "level": "ERROR", "msg": "x"})]
    out = _mini(tmp_path, good)
    r = run(LP / "parse_logs.py", out, "--time-window", "2026-11-21T00:00:00Z/2026-11-21T01:00:00Z")
    assert r.returncode != 0 and "no log lines" in (r.stdout + r.stderr)


def test_crlf_input_is_fine(tmp_path):
    rows = [json.dumps({"line_id": f"L{i:06d}", "ts": f"2026-11-20T09:0{i}:00Z", "service": "s", "level": "ERROR", "msg": "boom"})
            for i in range(1, 6)]
    out = tmp_path / "o"
    (out / "work" / "redacted").mkdir(parents=True)
    (out / "redaction-report.json").write_text("{}")
    (out / "work" / "redacted" / "s.jsonl").write_bytes(("\r\n".join(rows) + "\r\n").encode())
    assert run(LP / "parse_logs.py", out).returncode == 0
    assert run(LP / "cluster_errors.py", out).returncode == 0
    assert run(LP / "build_timeline.py", out).returncode == 0


def test_simple_yaml_service_map(tmp_path):
    p = tmp_path / "map.yaml"
    p.write_text("api: [orders, stock]\norders:\n  - db\n# comment\n")
    assert load_service_map(p) == {"api": ["orders", "stock"], "orders": ["db"]}
