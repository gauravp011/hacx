import json
from pathlib import Path

import pytest

from conftest import REPO, SCENARIO_IDS, answer

jsonschema = pytest.importorskip("jsonschema")
S = REPO / "schemas"


def schema(name):
    return json.loads((S / name).read_text(encoding="utf-8"))


def test_generated_files_match_schemas(scenarios):
    for sid in SCENARIO_IDS:
        jsonschema.validate(answer(sid), schema("answer_key.schema.json"))
        jsonschema.validate(json.loads((scenarios / sid / "deploys.json").read_text()), schema("deploy_event.schema.json"))
        with open(next((scenarios / sid / "logs").glob("*.jsonl")), encoding="utf-8") as fh:
            for i, raw in enumerate(fh):
                jsonschema.validate(json.loads(raw), schema("log_line.schema.json"))
                if i > 200:
                    break


def test_sample_evidence_matches_schema():
    ev = json.loads((REPO / "examples" / "sample-run" / "loud-red-herring" / "evidence.json").read_text())
    jsonschema.validate(ev, schema("evidence.schema.json"))


def test_nullable_trigger_and_none_root_cause():
    a = answer("cert-expiry")
    assert a["trigger_event_id"] is None
    jsonschema.validate(a, schema("answer_key.schema.json"))
    q = answer("quiet-day")
    assert q["root_cause_id"] == "NONE" and q["root_cause_service"] is None
    jsonschema.validate(q, schema("answer_key.schema.json"))
