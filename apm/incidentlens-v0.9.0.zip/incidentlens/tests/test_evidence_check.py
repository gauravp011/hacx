import json
import shutil

import pytest

from conftest import REPO, SKILLS, run

CHK = SKILLS / "evidence-check" / "scripts" / "check_evidence.py"
SAMPLE = REPO / "examples" / "sample-run" / "loud-red-herring"


@pytest.fixture
def out(prepared, tmp_path):
    o = tmp_path / "rep"
    shutil.copytree(prepared["loud-red-herring"], o)
    for f in ("evidence.json", "rca.md", "postmortem.md", "timeline.md"):
        shutil.copy(SAMPLE / f, o / f)
    return o


def result(o):
    return json.loads((o / "evidence-check.json").read_text())


def test_sample_passes(out):
    r = run(CHK, out, "--deploys", out / "work" / "deploys.json")
    assert r.returncode == 0, r.stdout
    assert result(out)["unverified_claims"] == []


def test_invalid_line_id_fails(out):
    ev = json.loads((out / "evidence.json").read_text())
    ev["hypotheses"][0]["evidence_line_ids"] = ["L999999"]
    (out / "evidence.json").write_text(json.dumps(ev))
    assert run(CHK, out).returncode == 1
    assert "L999999" in result(out)["invalid_line_ids"]
    assert result(out)["top_hypothesis_has_valid_evidence"] is False


def test_unsupported_claim_reported(out):
    with open(out / "rca.md", "a") as fh:
        fh.write("\nThe root cause was a cosmic ray hitting the server.\n")
    run(CHK, out)
    assert any("cosmic ray" in c for c in result(out)["unverified_claims"])
    assert run(CHK, out, "--strict-claims").returncode == 1


def test_leak_detected(out):
    with open(out / "postmortem.md", "a") as fh:
        fh.write("\nContact jane.doe@example.test with password=FAKE-oops\n")
    assert run(CHK, out).returncode == 1
    assert set(result(out)["leaked_secret_categories"]) >= {"EMAIL", "KEY_VALUE_SECRET"}
    assert "jane.doe" not in (out / "evidence-check.json").read_text()


def test_unknown_event_and_schema_errors(out):
    ev = json.loads((out / "evidence.json").read_text())
    ev["hypotheses"][0]["related_event_ids"] = ["D999"]
    ev["hypotheses"][0]["root_cause_id"] = "ALIENS"
    (out / "evidence.json").write_text(json.dumps(ev))
    assert run(CHK, out, "--deploys", out / "work" / "deploys.json").returncode == 1
    r = result(out)
    assert r["unknown_event_ids"] == ["D999"] and r["schema_errors"]


def test_insufficient_evidence_is_valid(out):
    (out / "evidence.json").write_text(json.dumps({"status": "insufficient_evidence", "hypotheses": []}))
    (out / "rca.md").write_text("# Root cause analysis\n\nNo anomaly stood out from normal behaviour.\n")
    (out / "postmortem.md").write_text("# No root cause established\n")
    assert run(CHK, out).returncode == 0
