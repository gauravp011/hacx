import json
import sys

import pytest

from conftest import SCENARIO_IDS, SKILLS, answer, run

sys.path.insert(0, str(SKILLS / "redact-logs" / "scripts"))
from redact import find_leaks, luhn_ok, redact_text  # noqa: E402

POSITIVE = {
    "EMAIL": "mail sam.lee@example.test now",
    "IPV4": "client 10.1.2.3 blocked",
    "IPV6": "probe from fd12:3456:789a::1f2e ok",
    "BEARER_TOKEN": "Authorization: Bearer FAKE-tok-0123456789abcdef",
    "JWT": "token eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ4In0.FAKEsignature123",
    "KEY_VALUE_SECRET": "connect password=FAKE-hunter2 host=db",
    "HEX_SECRET": "key 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b",
    "BASE64_SECRET": "blob RkFLRS1zZWNyZXQtMDEyMzQ1Njc4OWFiY2RlZjAxMjM0NTY3",
    "CARD_NUMBER": "card 4111111111111111 ok",
}
NEGATIVE = [
    "GET /api/products 200 in 85ms", "release v2.4.1 deployed", "Order 100231 created", "listening on port 8080",
    "trace 9f2c1a7e", "Timeout acquiring DB connection after 5000ms (pool active=5/5, waiting=12)",
    "at 09:32:00 the job ran", "Heap usage 85% of 2048MB", "Decoder error: unhandled frame type 0x1F",
    "card-like 4111111111111112 fails luhn", "secret: <b>1</b>",
]


@pytest.mark.parametrize("cat,text", POSITIVE.items())
def test_each_category_detected(cat, text):
    counts = {}
    out = redact_text(text, counts)
    assert f"[REDACTED:{cat}]" in out, out
    assert cat in counts


@pytest.mark.parametrize("text", NEGATIVE)
def test_no_false_positives(text):
    counts = {}
    assert redact_text(text, counts) == text, counts


def test_luhn():
    assert luhn_ok("4111111111111111") and not luhn_ok("4111111111111112")


def test_standard_mode_keeps_private_ipv4():
    assert redact_text("client 10.1.2.3", {}, "standard") == "client 10.1.2.3"
    assert "[REDACTED:IPV4]" in redact_text("client 10.1.2.3", {}, "strict")


def test_recall_100_percent_on_all_scenarios(prepared):
    for sid in SCENARIO_IDS:
        red = "".join(p.read_text(encoding="utf-8") for p in (prepared[sid] / "work" / "redacted").glob("*.jsonl"))
        for s in answer(sid)["planted_secrets"]:
            assert s["value"] not in red, (sid, s["type"])
        report = (prepared[sid] / "redaction-report.json").read_text(encoding="utf-8")
        for s in answer(sid)["planted_secrets"]:
            assert s["value"] not in report
        assert not find_leaks(report)


def test_structural_fields_and_line_order_preserved(scenarios, prepared):
    sid = "db-pool-exhaustion"
    for f in (scenarios / sid / "logs").glob("*.jsonl"):
        a = [json.loads(x) for x in f.read_text(encoding="utf-8").splitlines()]
        b = [json.loads(x) for x in (prepared[sid] / "work" / "redacted" / f.name).read_text(encoding="utf-8").splitlines()]
        assert [r["line_id"] for r in a] == [r["line_id"] for r in b]
        for x, y in zip(a, b):
            for k in ("ts", "level", "service", "trace_id"):
                assert x.get(k) == y.get(k)


def test_missing_input_fails_clearly(tmp_path):
    r = run(SKILLS / "redact-logs" / "scripts" / "redact.py", tmp_path / "nope", tmp_path / "out")
    assert r.returncode != 0 and "REDACTION FAILED" in (r.stdout + r.stderr)
    (tmp_path / "empty").mkdir()
    r = run(SKILLS / "redact-logs" / "scripts" / "redact.py", tmp_path / "empty", tmp_path / "out")
    assert r.returncode != 0
