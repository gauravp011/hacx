import json
import shutil

from conftest import REPO, run

SAMPLE = REPO / "examples" / "sample-run" / "loud-red-herring"


def make_run(root, scenario, name, evidence, minutes=5, credits=10):
    d = root / scenario / name
    d.mkdir(parents=True)
    (d / "evidence.json").write_text(json.dumps(evidence))
    (d / "evidence-check.json").write_text(json.dumps({"passed": True, "unverified_claims": []}))
    (d / "meta.json").write_text(json.dumps({"minutes": minutes, "credits": credits}))


def test_scoring(tmp_path, scenarios):
    runs = tmp_path / "runs"
    good = json.loads((SAMPLE / "evidence.json").read_text())
    make_run(runs, "loud-red-herring", "fake-run1", good)
    wrong = json.loads(json.dumps(good))
    wrong["hypotheses"][0]["service"] = "api-gateway"
    wrong["hypotheses"][0]["root_cause_id"] = "DEPENDENCY_LATENCY"
    make_run(runs, "loud-red-herring", "fake-run2", wrong)
    make_run(runs, "quiet-day", "fake-run1", {"status": "insufficient_evidence", "hypotheses": []})
    r = run(REPO / "examples" / "evaluation" / "run_eval.py", "--runs", runs, "--out", tmp_path / "ev")
    assert r.returncode == 0, r.stdout + r.stderr
    sc = json.loads((tmp_path / "ev" / "scorecard.json").read_text())
    m = sc["by_model"]["fake"]
    assert m["runs"] == 3 and m["top1"] == "67%" and m["repeatability"] == "0%"
    assert m["credits_per_correct"] == 15.0
    assert (tmp_path / "ev" / "scorecard.md").exists()


def test_prepare_eval_copies_no_answers(tmp_path, scenarios):
    r = run(REPO / "examples" / "evaluation" / "prepare_eval.py", "--scenario", "cert-expiry", "--dest", tmp_path / "ws")
    assert r.returncode == 0, r.stdout
    files = {p.name for p in (tmp_path / "ws").rglob("*")}
    assert "answer.json" not in files and "symptom.txt" in files
    assert (tmp_path / "ws" / "case-04" / "logs").is_dir()
