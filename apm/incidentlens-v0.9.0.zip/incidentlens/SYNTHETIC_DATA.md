# Synthetic data

IncidentLens is developed and evaluated **only on synthetic data**. No client data, real systems, real hostnames, real credentials or personal data are used anywhere in this repository.

## Fictional systems
| System | What it is | Services |
|---|---|---|
| ShopSphere | Web shop | `api-gateway`, `order-service`, `payment-service`, `inventory-service` (+ stubs `orders-db`, `inventory-db`, `payment-provider-stub`) |
| FleetSense | Embedded cold-chain truck telemetry | `sensor-node` (40 devices), `edge-gateway` (4 gateways), `telemetry-ingest`, `fleet-api` (+ stub `telemetry-db`) |

## Scenarios
Each scenario is 90 minutes of logs (17k–28k lines) with realistic background traffic, steady background warnings, at least two unrelated "red herring" bursts, change events, and an injected fault with a downstream cascade. Answer keys live next to the logs in `answer.json` and are **never** copied into evaluation workspaces.

| Scenario | System | Difficulty | Reported symptom |
|---|---|---|---|
| db-pool-exhaustion | ShopSphere | standard | Checkout starts failing with 503s |
| bad-deploy | ShopSphere | standard | Some orders fail after a release |
| memory-leak | ShopSphere | standard | Payments time out intermittently |
| cert-expiry | ShopSphere | standard | All payments fail suddenly |
| dependency-latency | ShopSphere | standard | Checkout becomes slow, then times out |
| disk-full | ShopSphere | standard | Inventory keeps crashing and checkout fails |
| loud-red-herring | ShopSphere | hard | Checkout fails while the gateway is flooded with errors |
| fleet-firmware-crash | FleetSense | hard | Truck dashboards show stale temperature data |
| quiet-day | ShopSphere | control | Someone reported checkout felt slow |
| overlapping-changes | ShopSphere | hard | Checkout fails shortly after two changes |

## Planted fake secrets
Every scenario contains one fake secret of each redaction category to measure redaction recall: `example.test` e-mail, private IPv4 (10.x / 192.168.x), unique-local IPv6 (fd12:…), `Bearer FAKE-tok-…`, a JWT-like string with a FAKE signature, `password=FAKE-…`/`api_key=FAKE-…`, a 40-character random hex key, a base64 blob encoding `FAKE-secret-…`, and a well-known payment test card number (e.g. 4111 1111 1111 1111).

## Reproducibility
- Generator: `examples/generator/generate_incident.py`; definitions: `examples/generator/scenarios.json` (data-driven: a new scenario needs no code).
- One `random.Random(seed)` per scenario, fixed base time `2026-11-20T09:00:00Z`, no wall-clock reads.
- `examples/generator/scenarios.lock.json` holds SHA-256 hashes of every generated file.

```bash
python examples/generator/generate_incident.py --scenario all --check
```
regenerates all scenarios and verifies them byte-for-byte against the lock file. Generated logs are not committed (they are ~45 MB); the generator, seeds and lock file are.
