"""IncidentLens evidence gate: when an agent session stops, re-check ./incident-report if it changed.

Non-blocking by design (always exits 0): it prints the evidence-check result so the user sees it.
Looks for the installed evidence-check skill in the usual skill folders. Python 3.10+ stdlib only.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

CANDIDATES = [".kiro/skills", ".agents/skills", ".github/skills", ".claude/skills", ".cursor/skills", ".apm/skills"]


def main() -> int:
    out = Path("incident-report")
    ev, chk = out / "evidence.json", out / "evidence-check.json"
    if not ev.exists() or (chk.exists() and chk.stat().st_mtime >= ev.stat().st_mtime):
        return 0
    here = Path(__file__).resolve()
    roots = [Path.cwd() / c for c in CANDIDATES] + [p / "skills" for p in here.parents[:4]]
    script = next((r / "evidence-check" / "scripts" / "check_evidence.py" for r in roots
                   if (r / "evidence-check" / "scripts" / "check_evidence.py").exists()), None)
    if not script:
        print("IncidentLens evidence gate: evidence-check skill not found; skipped.")
        return 0
    res = subprocess.run([sys.executable, str(script), str(out)], capture_output=True, text=True)
    print("IncidentLens evidence gate: " + (res.stdout.strip().splitlines() or ["no output"])[0])
    return 0


if __name__ == "__main__":
    sys.exit(main())
