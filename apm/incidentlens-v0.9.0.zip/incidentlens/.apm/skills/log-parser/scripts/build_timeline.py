"""Build the per-minute timeline and a compact summary.json for reasoning.

Usage:
    python build_timeline.py <output_dir> [--deploys deploys.json] [--service-map service_map.json]

Reads work/parsed.jsonl, work/parse-report.json, work/clusters.json.
Writes:
  work/timeline.json  per-minute totals / warnings / errors per service, deploy markers
  work/summary.json   what the reasoning step reads first (< 200 lines):
                      services ordered by first anomaly AND by error volume (they often differ),
                      notable clusters with hosts and nearby changes, volume anomalies, top events.
"""
from __future__ import annotations

import argparse
import statistics
import sys
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import (LEVEL_RANK, load_json, load_parsed, load_service_map, minute_of, parse_ts,  # noqa: E402
                     work_dir, write_json)

CHANGE_WINDOW = timedelta(minutes=15)


def _minutes(w0: str, w1: str) -> list[str]:
    t, end, out = parse_ts(w0).replace(second=0, microsecond=0), parse_ts(w1), []
    while t <= end:
        out.append(t.strftime("%Y-%m-%dT%H:%M"))
        t += timedelta(minutes=1)
    return out


def _onset(series: list[int], minutes: list[str], min_abs: int, factor: float = 3.0) -> str | None:
    """First minute where the series exceeds baseline mean + factor*sd for 2 consecutive minutes."""
    base_n = max(5, len(series) // 5)
    base = series[:base_n]
    mu, sd = statistics.mean(base), statistics.pstdev(base)
    thr = max(mu + factor * sd, mu * 2, mu + min_abs)
    for i in range(base_n, len(series) - 1):
        if series[i] > thr and series[i + 1] > thr:
            return minutes[i]
    return None


def run(output_dir: Path, deploys_path: Path | None, service_map_path: Path | None) -> dict:
    report = load_json(work_dir(output_dir) / "parse-report.json")
    clusters = load_json(work_dir(output_dir) / "clusters.json")
    deploys = load_json(deploys_path) if deploys_path else []
    if deploys_path and not deploys_path.exists():
        raise SystemExit(f"Deploys file not found: {deploys_path}")
    smap = load_service_map(service_map_path)
    w0, w1 = report["window"]
    minutes = _minutes(w0, w1)
    idx = {m: i for i, m in enumerate(minutes)}
    services = report["services"]
    series = {s: {"total": [0] * len(minutes), "warn": [0] * len(minutes), "error": [0] * len(minutes)}
              for s in services}
    for r in load_parsed(output_dir):
        i = idx.get(minute_of(r["ts"]))
        if i is None:
            continue
        s = series[r["service"]]
        s["total"][i] += 1
        if r["level"] == "WARN":
            s["warn"][i] += 1
        elif LEVEL_RANK[r["level"]] >= LEVEL_RANK["ERROR"]:
            s["error"][i] += 1

    notable = [c for c in clusters if c["kind"] == "notable"]
    dep_t = [(d, parse_ts(d["ts"])) for d in deploys]

    def nearby_changes(ts: str) -> list[str]:
        t = parse_ts(ts)
        return [d["event_id"] for d, dt in dep_t if timedelta(0) <= t - dt <= CHANGE_WINDOW]

    svc_info = []
    for s in services:
        mine = [c for c in notable if c["service"] == s]
        err = [c for c in mine if LEVEL_RANK[c["level"]] >= LEVEL_RANK["ERROR"]]
        vol = _onset(series[s]["total"], minutes, min_abs=20)
        espike = _onset(series[s]["error"], minutes, min_abs=5)
        candidates = [c["first_seen"][:16] for c in mine] + [x for x in (vol, espike) if x]
        svc_info.append({
            "service": s, "first_anomaly": min(candidates) if candidates else None,
            "first_notable_error": err[0]["first_seen"] if err else None,
            "error_spike_onset": espike, "volume_anomaly_onset": vol,
            "changes_before_volume_surge": nearby_changes(vol + ":00Z") if vol else [],
            "errors_total": sum(series[s]["error"]), "errors_peak_per_min": max(series[s]["error"]),
            "lines_total": sum(series[s]["total"]), "notable_clusters": [c["cluster_id"] for c in mine],
            "calls": smap.get(s, []), "called_by": sorted(k for k, v in smap.items() if s in v),
        })
    by_anomaly = [x["service"] for x in sorted((x for x in svc_info if x["first_anomaly"]),
                                                key=lambda x: x["first_anomaly"])]
    by_volume = [x["service"] for x in sorted(svc_info, key=lambda x: -x["errors_total"]) if x["errors_total"]]

    compact = [{
        "cluster_id": c["cluster_id"], "service": c["service"], "level": c["level"], "example": c["example"],
        **({"last_example": c["last_example"]} if c.get("last_example") and c["last_example"] != c["example"] else {}),
        "count": c["count"], "first_seen": c["first_seen"], "last_seen": c["last_seen"],
        "peak_per_min": c["peak_per_min"], "hosts": c["hosts"], "only_on_hosts": c["only_on_hosts"],
        "nearby_changes": nearby_changes(c["first_seen"]), "samples": c["samples"],
    } for c in notable]

    events = [{"ts": d["ts"], "type": "change", "ref": d["event_id"],
               "text": f"{d['change_type']} {d['service']} {d.get('version', '')}: {d.get('details', '')}".strip()}
              for d in deploys]
    events += [{"ts": c["first_seen"], "type": "cluster_onset", "ref": c["cluster_id"],
                "text": f"{c['service']} {c['level']} x{c['count']}: {c['example'][:90]}"} for c in notable]
    for x in svc_info:
        if x["volume_anomaly_onset"]:
            events.append({"ts": x["volume_anomaly_onset"] + ":00Z", "type": "volume_anomaly", "ref": x["service"],
                           "text": f"log volume surge in {x['service']}"})
        if x["error_spike_onset"]:
            events.append({"ts": x["error_spike_onset"] + ":00Z", "type": "error_spike", "ref": x["service"],
                           "text": f"error rate spike in {x['service']} (peak {x['errors_peak_per_min']}/min)"})
    events.sort(key=lambda e: e["ts"])

    timeline = {"minutes": minutes, "series": series,
                "changes": [{"event_id": d["event_id"], "ts": d["ts"], "service": d["service"],
                             "details": d.get("details", "")} for d in deploys]}
    summary = {
        "window": [w0, w1], "lines": report["lines"], "corrupted_lines": report["corrupted_lines"],
        "services_by_first_anomaly": by_anomaly, "services_by_error_volume": by_volume,
        "note": "The loudest service is often a symptom. Compare first-anomaly order with the service map.",
        "services": svc_info, "changes": deploys, "service_map": smap,
        "notable_clusters": compact, "top_events": events[:20],
        "background_clusters": sum(1 for c in clusters if c["kind"] == "background"),
        "other_error_clusters": [{"cluster_id": c["cluster_id"], "service": c["service"], "level": c["level"],
                                  "kind": c["kind"], "count": c["count"], "first_seen": c["first_seen"],
                                  "example": c["example"][:120], "samples": c["samples"]}
                                 for c in clusters if c["kind"] != "notable"
                                 and LEVEL_RANK[c["level"]] >= LEVEL_RANK["ERROR"]][:10],
    }
    write_json(work_dir(output_dir) / "timeline.json", timeline, compact=True)
    write_json(work_dir(output_dir) / "summary.json", summary, compact=True)
    return summary


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("output_dir")
    ap.add_argument("--deploys")
    ap.add_argument("--service-map")
    a = ap.parse_args(argv)
    s = run(Path(a.output_dir), Path(a.deploys) if a.deploys else None,
            Path(a.service_map) if a.service_map else None)
    print(f"Timeline built. First anomaly order: {s['services_by_first_anomaly']}; "
          f"error volume order: {s['services_by_error_volume']}; {len(s['notable_clusters'])} notable clusters")
    return 0


if __name__ == "__main__":
    sys.exit(main())
