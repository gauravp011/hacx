"""Group WARN+ log lines into message templates ("clusters") and classify them.

Usage:
    python cluster_errors.py <output_dir> [--min-severity WARN]

Reads work/parsed.jsonl and work/parse-report.json; writes work/clusters.json.
Each cluster: template, example message, count, first/last seen, active minutes, peak per minute,
hosts, 3 sample line_ids (first, peak, last) and kind:
  background = steady low-rate noise present through most of the window
  notable    = appears in bursts or surges: a candidate cause, symptom or red herring
  rare       = fewer than 3 lines
"""
from __future__ import annotations

import argparse
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import LEVEL_RANK, load_json, load_parsed, minute_of, parse_ts, template, work_dir, write_json  # noqa: E402


def run(output_dir: Path, min_severity: str | None = None) -> list[dict]:
    report = load_json(work_dir(output_dir) / "parse-report.json")
    min_rank = LEVEL_RANK[(min_severity or report["min_severity"]).upper()]
    w0, w1 = report["window"]
    window_minutes = max(1, int((parse_ts(w1) - parse_ts(w0)).total_seconds() // 60) + 1)
    service_hosts: dict[str, set] = defaultdict(set)
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for r in load_parsed(output_dir):
        if not (w0 <= r["ts"] <= w1):
            continue
        service_hosts[r["service"]].add(r.get("host"))
        if LEVEL_RANK[r["level"]] >= min_rank:
            groups[(r["service"], r["level"], template(r["msg"]))].append(r)
    clusters = []
    for (svc, lvl, tpl), rows in groups.items():
        per_min = Counter(minute_of(r["ts"]) for r in rows)
        peak_minute, peak = per_min.most_common(1)[0]
        peak_row = next(r for r in rows if minute_of(r["ts"]) == peak_minute)
        hosts = Counter(r.get("host") for r in rows)
        span_min = (parse_ts(rows[-1]["ts"]) - parse_ts(rows[0]["ts"])).total_seconds() / 60 + 1
        spread = span_min / window_minutes
        if len(rows) < 3:
            kind = "rare"
        elif spread >= 0.6 and len(rows) / span_min <= 2 and peak <= max(5, 4 * len(rows) / span_min):
            kind = "background"
        else:
            kind = "notable"
        all_hosts = {h for h in service_hosts[svc] if h}
        top = [h for h, _ in hosts.most_common()]
        concentrated = None
        for k in range(1, max(1, len(all_hosts) // 2) + 1 if len(rows) >= 10 else 0):
            if k < len(all_hosts) and sum(hosts[h] for h in top[:k]) / len(rows) >= 0.95:
                concentrated = sorted(top[:k])
                break
        clusters.append({
            "service": svc, "level": lvl, "template": tpl, "example": rows[0]["msg"], "last_example": rows[-1]["msg"],
            "count": len(rows),
            "first_seen": rows[0]["ts"], "last_seen": rows[-1]["ts"], "active_minutes": len(per_min),
            "peak_per_min": peak, "peak_minute": peak_minute, "kind": kind,
            "hosts": dict(hosts.most_common(5)), "host_count": len(hosts), "service_host_count": len(all_hosts),
            "only_on_hosts": concentrated,
            "samples": list(dict.fromkeys([rows[0]["line_id"], peak_row["line_id"], rows[-1]["line_id"]])),
        })
    clusters.sort(key=lambda c: (c["first_seen"], -LEVEL_RANK[c["level"]], c["service"]))
    for i, c in enumerate(clusters, 1):
        c["cluster_id"] = f"C{i:03d}"
    write_json(work_dir(output_dir) / "clusters.json", clusters)
    return clusters


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("output_dir")
    ap.add_argument("--min-severity")
    a = ap.parse_args(argv)
    cl = run(Path(a.output_dir), a.min_severity)
    kinds = Counter(c["kind"] for c in cl)
    print(f"{len(cl)} clusters: {kinds.get('notable', 0)} notable, {kinds.get('background', 0)} background, "
          f"{kinds.get('rare', 0)} rare -> work/clusters.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
