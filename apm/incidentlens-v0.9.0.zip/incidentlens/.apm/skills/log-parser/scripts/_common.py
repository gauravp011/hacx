"""Shared helpers for the log-parser scripts (Python 3.10+ standard library only)."""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

LEVELS = ["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"]
LEVEL_RANK = {lv: i for i, lv in enumerate(LEVELS)}
LINE_ID = re.compile(r"^L\d{6,}$")

_MASKS = [
    (re.compile(r"\[REDACTED:[A-Z0-9_]+\]"), "<SECRET>"),
    (re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I), "<UUID>"),
    (re.compile(r"\b0x[0-9a-fA-F]+\b"), "<HEXNUM>"),
    (re.compile(r"\b[0-9a-f]{12,}\b", re.I), "<HEX>"),
    (re.compile(r"(?<=[A-Za-z])-\d+\b"), "-<N>"),
    (re.compile(r"\d+(\.\d+)?"), "<N>"),
]


def template(msg: str) -> str:
    """Mask variable parts (numbers, ids, secrets) so similar messages group together."""
    for pat, rep in _MASKS:
        msg = pat.sub(rep, msg)
    return msg


def parse_ts(ts: str) -> datetime:
    """Parse an ISO-8601 timestamp (with Z or offset) into an aware UTC datetime."""
    return datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone(timezone.utc)


def minute_of(ts: str) -> str:
    return ts[:16]


def work_dir(output_dir: Path) -> Path:
    return output_dir / "work"


def read_jsonl(path: Path):
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            raw = raw.strip()
            if raw:
                yield json.loads(raw)


def load_parsed(output_dir: Path) -> list[dict]:
    p = work_dir(output_dir) / "parsed.jsonl"
    if not p.exists():
        raise SystemExit(f"Missing {p}. Run parse_logs.py first.")
    return list(read_jsonl(p))


def load_json(path: Path, default=None):
    if not path.exists():
        if default is not None:
            return default
        raise SystemExit(f"Missing {path}.")
    return json.loads(path.read_text(encoding="utf-8"))


def _dump(obj, indent: int = 0) -> str:
    """Readable but compact JSON: dicts/lists of containers are expanded, leaf dicts/lists stay on one line."""
    pad, inner = "  " * indent, "  " * (indent + 1)
    if isinstance(obj, dict) and any(isinstance(v, (dict, list)) and v and
                                     any(isinstance(x, (dict, list)) for x in (v.values() if isinstance(v, dict) else v))
                                     for v in obj.values()):
        items = [f"{inner}{json.dumps(k)}: {_dump(v, indent + 1)}" for k, v in obj.items()]
        return "{\n" + ",\n".join(items) + "\n" + pad + "}"
    if isinstance(obj, dict) and len(json.dumps(obj)) > 100:
        items = [f"{inner}{json.dumps(k)}: {json.dumps(v)}" for k, v in obj.items()]
        return "{\n" + ",\n".join(items) + "\n" + pad + "}"
    if isinstance(obj, list) and any(isinstance(x, (dict, list)) for x in obj):
        return "[\n" + ",\n".join(inner + json.dumps(x) for x in obj) + "\n" + pad + "]"
    return json.dumps(obj)


def write_json(path: Path, obj, compact: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = _dump(obj) if compact else json.dumps(obj, indent=2)
    path.write_text(text + "\n", encoding="utf-8")


def load_service_map(path: Path | None) -> dict[str, list[str]]:
    """Read service_map.json, or a simple YAML form 'svc: [a, b]' / 'svc:\\n  - a' without PyYAML."""
    if not path:
        return {}
    if not path.exists():
        raise SystemExit(f"Service map not found: {path}")
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".json" or text.lstrip().startswith("{"):
        return {k: list(v) for k, v in json.loads(text).items()}
    smap: dict[str, list[str]] = {}
    current = None
    for line in text.splitlines():
        line = line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        m = re.match(r"^([\w.-]+):\s*(\[(.*)\])?\s*$", line)
        if m:
            current = m.group(1)
            smap[current] = [x.strip().strip("'\"") for x in (m.group(3) or "").split(",") if x.strip()]
        elif current and line.strip().startswith("- "):
            smap[current].append(line.strip()[2:].strip().strip("'\""))
    return smap
