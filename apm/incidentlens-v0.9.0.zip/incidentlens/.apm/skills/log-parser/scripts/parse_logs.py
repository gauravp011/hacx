"""Normalise redacted JSONL logs into <output_dir>/work/parsed.jsonl (all lines, time-ordered).

Usage:
    python parse_logs.py <output_dir> [--time-window START/END] [--min-severity WARN]

Reads <output_dir>/work/redacted/*.jsonl (produced by redact-logs). Refuses unredacted input.
Writes work/parsed.jsonl and work/parse-report.json (window, counts, corrupted lines).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import LEVEL_RANK, LEVELS, LINE_ID, parse_ts, work_dir, write_json  # noqa: E402

LEVEL_ALIASES = {"WARNING": "WARN", "ERR": "ERROR", "CRITICAL": "FATAL", "CRIT": "FATAL", "SEVERE": "ERROR",
                 "EMERG": "FATAL", "ALERT": "FATAL", "NOTICE": "INFO", "INFORMATION": "INFO", "FINE": "DEBUG"}


def normalise_level(level: str) -> str:
    lv = str(level or "INFO").upper()
    lv = LEVEL_ALIASES.get(lv, lv)
    return lv if lv in LEVEL_RANK else "INFO"


def run(output_dir: Path, time_window: str | None = None, min_severity: str = "WARN",
        allow_unredacted: bool = False) -> dict:
    redacted = work_dir(output_dir) / "redacted"
    if not allow_unredacted and not (output_dir / "redaction-report.json").exists():
        raise SystemExit("REFUSING: no redaction-report.json found. Run redact-logs first; "
                         "IncidentLens never analyses unredacted logs.")
    files = sorted(redacted.glob("*.jsonl"))
    if not files:
        raise SystemExit(f"No redacted .jsonl files in {redacted}.")
    lines, corrupted = [], 0
    for f in files:
        for raw in open(f, encoding="utf-8", errors="replace"):
            if not raw.strip():
                continue
            try:
                rec = json.loads(raw)
                if not LINE_ID.match(str(rec.get("line_id"))):
                    raise ValueError("line_id")
                rec["ts"] = parse_ts(rec["ts"]).strftime("%Y-%m-%dT%H:%M:%S.%f")[:23] + "Z"
                rec["level"] = normalise_level(rec.get("level"))
                rec["service"] = str(rec.get("service") or f.stem)
                rec["msg"] = str(rec.get("msg", ""))
                lines.append(rec)
            except (KeyError, ValueError, TypeError, AttributeError):
                corrupted += 1
    total = len(lines) + corrupted
    if not lines:
        raise SystemExit("No parsable lines found.")
    if corrupted / total > 0.05:
        raise SystemExit(f"Too many corrupted lines: {corrupted}/{total} (>5%). Check the input format.")
    lines.sort(key=lambda r: (r["ts"], r["line_id"]))
    window = [lines[0]["ts"], lines[-1]["ts"]]
    if time_window:
        try:
            start, end = (parse_ts(x) for x in time_window.split("/"))
        except ValueError:
            raise SystemExit(f"Bad --time-window '{time_window}'. Use ISO START/END.")
        in_win = [r for r in lines if start <= parse_ts(r["ts"]) <= end]
        if not in_win:
            raise SystemExit(f"Time window {time_window} contains no log lines (logs span {window[0]} to {window[1]}).")
        window = [in_win[0]["ts"], in_win[-1]["ts"]]
    with open(work_dir(output_dir) / "parsed.jsonl", "w", encoding="utf-8", newline="\n") as fh:
        for r in lines:
            fh.write(json.dumps(r, separators=(",", ":")) + "\n")
    counts = {lv: 0 for lv in LEVELS}
    for r in lines:
        counts[r["level"]] += 1
    report = {"lines": len(lines), "corrupted_lines": corrupted, "window": window,
              "min_severity": normalise_level(min_severity), "services": sorted({r["service"] for r in lines}),
              "levels": {k: v for k, v in counts.items() if v}}
    write_json(work_dir(output_dir) / "parse-report.json", report)
    return report


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("output_dir")
    ap.add_argument("--time-window")
    ap.add_argument("--min-severity", default="WARN")
    ap.add_argument("--i-know-unredacted", action="store_true", help=argparse.SUPPRESS)
    a = ap.parse_args(argv)
    rep = run(Path(a.output_dir), a.time_window, a.min_severity, a.i_know_unredacted)
    print(f"Parsed {rep['lines']} lines ({rep['corrupted_lines']} corrupted skipped), "
          f"{len(rep['services'])} services, window {rep['window'][0]} .. {rep['window'][1]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
