"""Convert logs in common formats into IncidentLens JSONL (one file per service, global line_ids).

Usage:
    python convert_logs.py <input_file_or_folder> <out_dir> [--format auto] [--service NAME]
                           [--map mapping.json] [--year 2026]

Formats (--format):
  auto        detect per file (default)
  jsonl       JSON Lines; common field names are recognised (time/@timestamp, level/severity, msg/message, ...)
  json        a JSON array of log objects
  csv         CSV with a header row (same field-name recognition)
  cloudwatch  CloudWatch Logs export / `aws logs filter-log-events` JSON ({"events": [...]})
  datadog     Datadog log export JSON ({"data": [{"attributes": {...}}]} or a plain array)
  ecs         Elastic Common Schema NDJSON (@timestamp, log.level, service.name, message, host.name)
  plain       text lines; built-in patterns: ISO "<ts> <LEVEL> <service> <msg>", log4j/logback,
              Python logging, syslog (RFC 3164/5424), nginx/Apache access logs
Unknown format: the script exits with code 3 and prints sample lines. Write a mapping file and re-run with --map:
  {"type": "json", "fields": {"ts": "eventTime", "level": "sev", "service": "app", "msg": "text", "host": "node"}}
  {"type": "regex", "pattern": "^(?P<ts>\\\\S+ \\\\S+) \\\\[(?P<level>\\\\w+)\\\\] (?P<msg>.*)$", "ts_format": "%Y-%m-%d %H:%M:%S"}
Multi-line entries (e.g. stack traces) are appended to the previous line's message with " | ".
HTTP status codes map to levels when no level exists: 5xx -> ERROR, 4xx -> WARN.

Python 3.10+ standard library only. Writes conversion-report.json next to <out_dir>.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

FIELD_ALIASES = {
    "ts": ["ts", "timestamp", "@timestamp", "time", "datetime", "date", "eventTime", "event_time", "Timestamp",
           "TimeGenerated", "_time", "created", "asctime"],
    "level": ["level", "severity", "lvl", "log.level", "loglevel", "levelname", "status", "Severity", "priority",
              "severity_text", "SeverityText"],
    "service": ["service", "service.name", "app", "application", "component", "logger_name", "logStreamName",
                "logger", "source", "container_name", "kubernetes.container_name", "name"],
    "msg": ["msg", "message", "log", "text", "Message", "body", "Body", "event", "content"],
    "host": ["host", "host.name", "hostname", "node", "instance", "pod", "kubernetes.pod_name", "device"],
    "trace_id": ["trace_id", "traceId", "trace.id", "dd.trace_id", "correlation_id", "request_id"],
    "http_status": ["http_status", "status_code", "http.response.status_code", "http.status_code", "statusCode"],
    "latency_ms": ["latency_ms", "duration_ms", "elapsed_ms", "response_time_ms"],
}
LEVELS = {"TRACE": "TRACE", "DEBUG": "DEBUG", "FINE": "DEBUG", "INFO": "INFO", "INFORMATION": "INFO", "NOTICE": "INFO",
          "WARN": "WARN", "WARNING": "WARN", "ERROR": "ERROR", "ERR": "ERROR", "SEVERE": "ERROR", "FATAL": "FATAL",
          "CRITICAL": "FATAL", "CRIT": "FATAL", "ALERT": "FATAL", "EMERG": "FATAL", "EMERGENCY": "FATAL",
          "E": "ERROR", "W": "WARN", "I": "INFO", "D": "DEBUG", "F": "FATAL", "OK": "INFO"}
SYSLOG_SEV = ["FATAL", "FATAL", "FATAL", "ERROR", "WARN", "INFO", "INFO", "DEBUG"]
MONTHS = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                                      "Dec"], 1)}

PLAIN_PATTERNS = [
    ("log4j", re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?)\s+(?P<level>[A-Z]+)\s+"
                         r"(?:\d+\s+---\s+)?\[(?P<thread>[^\]]*)\]\s+(?P<service>[\w.$]+)\s*[:-]\s+(?P<msg>.*)$")),
    ("iso", re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\s+"
                       r"\[?(?P<level>(?i:TRACE|DEBUG|INFO|NOTICE|WARN|WARNING|ERROR|ERR|SEVERE|FATAL|CRITICAL|CRIT))\]?\s+\[?(?P<service>[\w.\-/]+)\]?:?\s+(?P<msg>.*)$")),
    ("python", re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d+)\s+-\s+(?P<service>[\w.]+)\s+-\s+"
                          r"(?P<level>[A-Z]+)\s+-\s+(?P<msg>.*)$")),
    ("syslog5424", re.compile(r"^<(?P<pri>\d+)>1\s+(?P<ts>\S+)\s+(?P<host>\S+)\s+(?P<service>\S+)\s+\S+\s+\S+\s+"
                              r"(?:-|\[.*?\])\s*(?P<msg>.*)$")),
    ("syslog3164", re.compile(r"^(?:<(?P<pri>\d+)>)?(?P<ts>[A-Z][a-z]{2}\s+\d{1,2} \d{2}:\d{2}:\d{2})\s+(?P<host>\S+)\s+"
                              r"(?P<service>[\w.\-/]+)(?:\[\d+\])?:\s*(?P<msg>.*)$")),
    ("access", re.compile(r'^(?P<client>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] "(?P<request>[^"]*)" (?P<http_status>\d{3}) '
                          r'(?P<bytes>\S+)(?: "[^"]*" "[^"]*")?(?: (?P<latency>[\d.]+))?.*$')),
]


def _get(obj: dict, dotted: str):
    if dotted in obj:
        return obj[dotted]
    cur = obj
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def _pick(obj: dict, field: str, mapping: dict | None):
    if mapping and field in mapping:
        return _get(obj, mapping[field])
    for alias in FIELD_ALIASES[field]:
        v = _get(obj, alias)
        if v not in (None, "") and not isinstance(v, (dict, list)):
            return v
    return None


def parse_time(value, year: int, fmt: str | None = None) -> datetime:
    """Parse many timestamp styles into an aware UTC datetime."""
    if isinstance(value, (int, float)) or (isinstance(value, str) and value.isdigit()):
        v = float(value)
        v = v / 1e9 if v > 1e17 else v / 1e6 if v > 1e14 else v / 1e3 if v > 1e11 else v
        return datetime.fromtimestamp(v, tz=timezone.utc)
    s = str(value).strip()
    if fmt:
        dt = datetime.strptime(s, fmt)
        return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)
    m = re.match(r"^(\d{2})/([A-Z][a-z]{2})/(\d{4}):(\d{2}):(\d{2}):(\d{2})\s*([+-]\d{4})?", s)  # access log
    if m:
        dt = datetime.strptime(s[:26] if m.group(7) else s[:20], "%d/%b/%Y:%H:%M:%S %z" if m.group(7) else "%d/%b/%Y:%H:%M:%S")
        return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)
    m = re.match(r"^([A-Z][a-z]{2})\s+(\d{1,2}) (\d{2}):(\d{2}):(\d{2})$", s)  # syslog 3164 (no year)
    if m:
        return datetime(year, MONTHS[m.group(1)], int(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5)),
                        tzinfo=timezone.utc)
    s = s.replace(",", ".").replace(" ", "T", 1)
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    s = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", s)
    m = re.match(r"^(.*\.\d{6})\d+(.*)$", s)  # trim nanoseconds
    if m:
        s = m.group(1) + m.group(2)
    dt = datetime.fromisoformat(s)
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def norm_level(level, status=None, pri=None) -> str:
    if pri is not None:
        return SYSLOG_SEV[int(pri) % 8]
    if level not in (None, ""):
        if isinstance(level, int) or str(level).isdigit():
            n = int(level)
            if n >= 100:
                return "ERROR" if n >= 500 else "WARN" if n >= 400 else "INFO"
            return SYSLOG_SEV[n % 8] if n < 8 else "ERROR" if n >= 17 else "WARN" if n >= 13 else "INFO"
        lv = LEVELS.get(str(level).strip().upper())
        if lv:
            return lv
    if status:
        try:
            st = int(status)
            return "ERROR" if st >= 500 else "WARN" if st >= 400 else "INFO"
        except ValueError:
            pass
    return "INFO"


def record(ts, level, service, msg, host=None, trace=None, status=None, latency=None, extra=None) -> dict:
    r = {"ts": ts, "service": str(service or "unknown").strip() or "unknown", "level": level,
         "msg": str(msg if msg is not None else "").replace("\n", " | ").strip()}
    if host:
        r["host"] = str(host)
    if trace:
        r["trace_id"] = str(trace)
    for k, v in (("http_status", status), ("latency_ms", latency)):
        try:
            if v not in (None, ""):
                r[k] = int(float(v))
        except (TypeError, ValueError):
            pass
    if extra:
        r["msg"] += " " + " ".join(f"{k}={v}" for k, v in extra.items())
    return r


def from_obj(obj: dict, default_service: str, year: int, mapping: dict | None, fmt: str | None) -> dict:
    ts = _pick(obj, "ts", mapping)
    if ts is None:
        raise ValueError("no timestamp field")
    status = _pick(obj, "http_status", mapping)
    lvl_raw = _pick(obj, "level", mapping)
    if isinstance(lvl_raw, str) and lvl_raw.isdigit() and int(lvl_raw) >= 100 and status is None:
        status = lvl_raw
    return record(parse_time(ts, year, fmt), norm_level(lvl_raw, status), _pick(obj, "service", mapping) or default_service,
                  _pick(obj, "msg", mapping), _pick(obj, "host", mapping), _pick(obj, "trace_id", mapping), status,
                  _pick(obj, "latency_ms", mapping))


def iter_objects(text: str, fmt: str) -> list[dict]:
    """Yield raw dicts for the JSON-shaped formats."""
    if fmt in ("jsonl", "ecs"):
        return [json.loads(l) for l in text.splitlines() if l.strip()]
    data = json.loads(text)
    if fmt == "cloudwatch":
        events = data.get("events", data) if isinstance(data, dict) else data
        out = []
        for e in events:
            msg = e.get("message", "")
            inner = None
            if msg.strip().startswith("{"):
                try:
                    inner = json.loads(msg)
                except ValueError:
                    inner = None
            if isinstance(inner, dict):
                inner.setdefault("timestamp", e.get("timestamp"))
                inner.setdefault("logStreamName", e.get("logStreamName"))
                out.append(inner)
            else:
                lvl = re.search(r"\b(TRACE|DEBUG|INFO|WARN|WARNING|ERROR|FATAL|CRITICAL)\b", msg)
                out.append({"timestamp": e.get("timestamp"), "message": msg, "level": lvl.group(1) if lvl else None,
                            "service": e.get("logGroupName", "").split("/")[-1] or None,
                            "host": e.get("logStreamName")})
        return out
    if fmt == "datadog":
        items = data.get("data", data) if isinstance(data, dict) else data
        out = []
        for it in items:
            a = it.get("attributes", it) if isinstance(it, dict) else {}
            flat = {**a.get("attributes", {}), **{k: v for k, v in a.items() if k != "attributes"}}
            out.append(flat)
        return out
    if fmt == "json":
        return data if isinstance(data, list) else data.get("logs") or data.get("records") or data.get("data") or []
    raise ValueError(fmt)


def detect(text: str) -> str:
    head = text.lstrip()[:2000]
    if head.startswith("{") and '"events"' in head and ('"logStreamName"' in text[:5000] or '"ingestionTime"' in text[:5000]):
        return "cloudwatch"
    if head.startswith("{") and '"data"' in head and '"attributes"' in text[:5000]:
        return "datadog"
    if head.startswith("["):
        return "datadog" if '"attributes"' in head[:800] else "json"
    if head.startswith("{"):
        first = head.splitlines()[0]
        try:
            obj = json.loads(first)
            return "ecs" if "@timestamp" in obj and ("log.level" in obj or "log" in obj) else "jsonl"
        except ValueError:
            return "json"
    first = head.splitlines()[0] if head else ""
    if first.count(",") >= 2 and any(a.lower() in first.lower() for a in ("timestamp", "time", "message", "msg")):
        return "csv"
    return "plain"


def convert_plain(text: str, default_service: str, year: int, mapping: dict | None) -> tuple[list[dict], int, str]:
    pats = [("custom", re.compile(mapping["pattern"]))] if mapping and mapping.get("type") == "regex" else PLAIN_PATTERNS
    fmt = mapping.get("ts_format") if mapping else None
    rows, unmatched, used = [], 0, set()
    for line in text.splitlines():
        if not line.strip():
            continue
        m = name = None
        for name, pat in pats:
            m = pat.match(line)
            if m:
                break
        if not m:
            if rows and (line[:1].isspace() or line.lstrip().startswith(("at ", "Caused by", "...", "Traceback", "File "))):
                rows[-1]["msg"] += " | " + line.strip()
            elif rows and not re.match(r"^\S*\d{2}:\d{2}", line):
                rows[-1]["msg"] += " | " + line.strip()
            else:
                unmatched += 1
            continue
        used.add(name)
        g = m.groupdict()
        if name == "access":
            req = g.get("request", "")
            lat = g.get("latency")
            rows.append(record(parse_time(g["ts"], year), norm_level(None, g["http_status"]), default_service,
                               f"{req} {g['http_status']}", g.get("client"), None, g["http_status"],
                               float(lat) * 1000 if lat and "." in lat else lat))
        else:
            svc, msg = g.get("service") or default_service, g.get("msg")
            if name == "log4j":  # the logger is a class name: keep the file's service, keep the logger in the message
                svc, msg = default_service, f"[{g.get('service')}] {msg}"
            rows.append(record(parse_time(g["ts"], year, fmt), norm_level(g.get("level"), g.get("http_status"), g.get("pri")),
                               svc, msg, g.get("host"), g.get("trace_id")))
    return rows, unmatched, ",".join(sorted(used)) or "none"


def convert_file(path: Path, fmt: str, service: str | None, year: int, mapping: dict | None) -> tuple[list[dict], dict]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    default_service = service or path.stem.split(".")[0]
    if mapping and mapping.get("type") == "json" and fmt == "auto":
        fmt = "jsonl" if text.lstrip().startswith("{") and "\n{" in text else "json"
    fmt = detect(text) if fmt == "auto" else fmt
    fields = mapping.get("fields") if mapping and mapping.get("type") == "json" else None
    tsf = mapping.get("ts_format") if mapping else None
    rows, bad, detail = [], 0, fmt
    if fmt == "plain":
        rows, bad, detail = convert_plain(text, default_service, year, mapping)
        detail = f"plain:{detail}"
    elif fmt == "csv":
        for obj in csv.DictReader(io.StringIO(text)):
            try:
                rows.append(from_obj(obj, default_service, year, fields, tsf))
            except (ValueError, TypeError, KeyError):
                bad += 1
    else:
        for obj in iter_objects(text, fmt):
            try:
                rows.append(from_obj(obj, default_service, year, fields, tsf))
            except (ValueError, TypeError, KeyError, AttributeError):
                bad += 1
    return rows, {"file": path.name, "format": detail, "converted": len(rows), "unconverted": bad}


def run(src: Path, out_dir: Path, fmt: str = "auto", service: str | None = None, year: int | None = None,
        mapping_path: Path | None = None) -> dict:
    year = year or datetime.now(timezone.utc).year
    mapping = json.loads(mapping_path.read_text(encoding="utf-8")) if mapping_path else None
    files = sorted(p for p in (src.rglob("*") if src.is_dir() else [src]) if p.is_file() and not p.name.startswith("."))
    if not files:
        raise SystemExit(f"No input files found at {src}")
    all_rows, reports = [], []
    for f in files:
        rows, rep = convert_file(f, fmt, service, year, mapping)
        all_rows += rows
        reports.append(rep)
    total_bad = sum(r["unconverted"] for r in reports)
    if not all_rows or total_bad > 0.2 * (len(all_rows) + total_bad):
        sample = files[0].read_text(encoding="utf-8-sig", errors="replace").splitlines()[:20]
        print("UNKNOWN FORMAT: could not convert most lines. First lines of", files[0].name, file=sys.stderr)
        for line in sample:
            print("  " + line[:200], file=sys.stderr)
        print("Write a mapping file (see --help) and re-run with --map mapping.json", file=sys.stderr)
        raise SystemExit(3)
    all_rows.sort(key=lambda r: (r["ts"], r["service"]))
    out_dir.mkdir(parents=True, exist_ok=True)
    by_service: dict[str, list[dict]] = {}
    for n, r in enumerate(all_rows, 1):
        line = {"line_id": f"L{n:06d}", "ts": r["ts"].strftime("%Y-%m-%dT%H:%M:%S.%f")[:23] + "Z"}
        line.update({k: v for k, v in r.items() if k != "ts"})
        by_service.setdefault(re.sub(r"[^\w.-]", "_", line["service"]), []).append(line)
    for svc, lines in by_service.items():
        with open(out_dir / f"{svc}.jsonl", "w", encoding="utf-8", newline="\n") as fh:
            for line in lines:
                fh.write(json.dumps(line, separators=(",", ":")) + "\n")
    report = {"input": str(src), "lines": len(all_rows), "services": sorted(by_service), "files": reports}
    (out_dir.parent / "conversion-report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src")
    ap.add_argument("out_dir")
    ap.add_argument("--format", default="auto",
                    choices=["auto", "jsonl", "json", "csv", "cloudwatch", "datadog", "ecs", "plain"])
    ap.add_argument("--service", help="service name when the logs don't contain one (default: file name)")
    ap.add_argument("--map", help="mapping JSON for unknown formats")
    ap.add_argument("--year", type=int, help="year for syslog timestamps without a year")
    a = ap.parse_args(argv)
    rep = run(Path(a.src), Path(a.out_dir), a.format, a.service, a.year, Path(a.map) if a.map else None)
    fmts = ", ".join(sorted({f["format"] for f in rep["files"]}))
    print(f"Converted {rep['lines']} lines from {len(rep['files'])} file(s) [{fmts}] into {len(rep['services'])} "
          f"service file(s): {', '.join(rep['services'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
