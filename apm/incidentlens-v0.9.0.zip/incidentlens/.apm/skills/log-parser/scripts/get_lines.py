"""Fetch exact (redacted) log lines by line_id so claims can be backed by evidence.

Usage:
    python get_lines.py <output_dir> --ids L004217,L004230
    python get_lines.py <output_dir> --range L004200:L004240
    python get_lines.py <output_dir> --around L004217 [--n 5]
    python get_lines.py <output_dir> --cluster C007            # sample lines of a cluster
Add --json for JSON lines output. Prints at most 200 lines.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import load_json, load_parsed, work_dir  # noqa: E402

MAX_LINES = 200


def fmt(r: dict) -> str:
    extra = " ".join(f"{k}={r[k]}" for k in ("http_status", "latency_ms") if k in r)
    return f"{r['line_id']} {r['ts']} {r['service']} {r.get('host', '-')} {r['level']} {r['msg']}" + (
        f" [{extra}]" if extra else "")


def select(output_dir: Path, ids: list[str] | None = None, rng: str | None = None, around: str | None = None,
           n: int = 5, cluster: str | None = None) -> list[dict]:
    rows = sorted(load_parsed(output_dir), key=lambda r: r["line_id"])
    if cluster:
        cl = {c["cluster_id"]: c for c in load_json(work_dir(output_dir) / "clusters.json")}
        if cluster not in cl:
            raise SystemExit(f"Unknown cluster {cluster}")
        ids = cl[cluster]["samples"]
    if ids:
        want = set(ids)
        found = [r for r in rows if r["line_id"] in want]
        missing = want - {r["line_id"] for r in found}
        if missing:
            print(f"WARNING: line_ids not found: {sorted(missing)}", file=sys.stderr)
        return found
    if rng:
        a, b = rng.split(":")
        return [r for r in rows if a <= r["line_id"] <= b][:MAX_LINES]
    if around:
        pos = next((i for i, r in enumerate(rows) if r["line_id"] == around), None)
        if pos is None:
            raise SystemExit(f"line_id not found: {around}")
        return rows[max(0, pos - n): pos + n + 1]
    raise SystemExit("Give --ids, --range, --around or --cluster")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("output_dir")
    ap.add_argument("--ids")
    ap.add_argument("--range")
    ap.add_argument("--around")
    ap.add_argument("--n", type=int, default=5)
    ap.add_argument("--cluster")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    rows = select(Path(a.output_dir), a.ids.split(",") if a.ids else None, a.range, a.around, a.n, a.cluster)
    for r in rows[:MAX_LINES]:
        print(json.dumps(r) if a.json else fmt(r))
    return 0 if rows else 1


if __name__ == "__main__":
    sys.exit(main())
