---
name: log-parser
description: Use when you need deterministic facts from incident logs - converting log formats to JSONL, clustering errors, building a per-minute timeline, or fetching exact log lines by ID as evidence. Works only on redacted logs.
---

# Log parser

Python does the counting so the model doesn't have to read thousands of lines. All scripts are standard-library Python 3.10+, live in `scripts/`, and take the run's output folder (default `incident-report/`).

Usually `../run-incident-analysis/scripts/prepare_incident.py` runs these for you. Run them individually only when re-doing one step.

## Order
| Step | Command | Writes |
|---|---|---|
| 0. Convert (only if not IncidentLens JSONL) | `python scripts/convert_logs.py <logs> <out>/work/converted --format auto` | one JSONL file per service |
| 1. Redact | `python ../redact-logs/scripts/redact.py <jsonl_dir> <out>/work/redacted` | redacted copies + `redaction-report.json` |
| 2. Parse | `python scripts/parse_logs.py <out> [--time-window START/END] [--min-severity WARN]` | `work/parsed.jsonl`, `work/parse-report.json` |
| 3. Cluster | `python scripts/cluster_errors.py <out>` | `work/clusters.json` |
| 4. Timeline | `python scripts/build_timeline.py <out> --deploys deploys.json --service-map service_map.json` | `work/timeline.json`, `work/summary.json` |
| Evidence | `python scripts/get_lines.py <out> --ids L1,L2` / `--range L1:L2` / `--around L1 --n 5` / `--cluster C006` | prints exact redacted lines |

`parse_logs.py` refuses to run unless redaction happened first.

## Rules
- Read `work/summary.json` first; it is short. Open `clusters.json` or `timeline.json` only for a specific question.
- **Never open `*.jsonl` files directly** (raw, converted or redacted). Use `get_lines.py`, which prints at most 200 lines.
- Quote line IDs exactly as printed.

## What the outputs mean
- **Cluster kinds:** `notable` = bursts or surges (candidate causes, symptoms or red herrings); `background` = steady low-rate noise across the window; `rare` = fewer than 3 lines.
- **`only_on_hosts`:** the cluster occurs (≥95%) on a subset of the service's hosts, e.g. a partial rollout.
- **`nearby_changes`:** changes within 15 minutes before the cluster's first line.
- **`services_by_first_anomaly` vs `services_by_error_volume`:** these often differ; the loudest service is frequently just the symptom.
- **Volume surge:** total lines per minute (all levels, including DEBUG) jumped for that service.

Example `summary.json` cluster entry:
```json
{"cluster_id": "C012", "service": "image-worker", "level": "ERROR", "example": "Resize failed: unsupported codec ...", "count": 412,
 "first_seen": "...T14:06:10.120Z", "only_on_hosts": ["worker-7"], "nearby_changes": ["D310"], "samples": ["L030117", "L031950"]}
```

## Supported input formats (`convert_logs.py --format`)
| Format | Recognised |
|---|---|
| `jsonl`, `json`, `csv` | field names such as `ts/timestamp/@timestamp/time`, `level/severity/status`, `service/app/logger`, `msg/message/log`, `host/hostname/pod` |
| `cloudwatch` | CloudWatch Logs export / `aws logs filter-log-events` JSON (`{"events": [...]}`); JSON messages are unpacked |
| `datadog` | Datadog log export (`{"data": [{"attributes": {...}}]}`) |
| `ecs` | Elastic Common Schema NDJSON (`@timestamp`, `log.level`, `service.name`, `message`, `host.name`) |
| `plain` | ISO `<ts> <LEVEL> <service> <msg>`, log4j/logback/Spring Boot, Python logging, syslog RFC 3164/5424, nginx/Apache access logs |

Details: multi-line stack traces are joined with ` | `; HTTP 5xx → ERROR, 4xx → WARN when no level exists; syslog priority → level; epoch s/ms/µs/ns timestamps are accepted; service defaults to the file name.

## Unknown formats
`convert_logs.py` exits with code **3** and prints the first 20 lines. Write a small mapping file and re-run with `--map`:
```json
{"type": "json", "fields": {"ts": "eventTime", "level": "sev", "service": "app", "msg": "text", "host": "node"}}
```
```json
{"type": "regex", "pattern": "^T=(?P<ts>\\d{8}-\\d{6}) SEV=(?P<level>\\d) MOD=(?P<service>\\w+) :: (?P<msg>.*)$", "ts_format": "%Y%m%d-%H%M%S"}
```
Named groups: `ts` (required), `msg` (required), `level`, `service`, `host`, `trace_id`. Numeric levels 0–7 are read as syslog severities. Test the regex against the sample lines before re-running.
