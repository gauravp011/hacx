---
name: postmortem-writer
description: Use after root-cause reasoning to write the incident outputs - evidence.json, rca.md, timeline.md (Mermaid) and a blameless postmortem.md - with every claim citing log line IDs, then render the HTML report.
---

# Post-mortem writer

Turn the rca-reasoning result into files people can review. Write into the run's output folder (default `incident-report/`).

## Files to write
1. **`evidence.json`** — exactly the JSON produced by rca-reasoning (see `../rca-reasoning/SKILL.md`, Output). Machine-checked.
2. **`rca.md`** — short technical RCA:
   - `# Root cause analysis` → one-paragraph answer with confidence and cited line IDs
   - `## Evidence` → bullet per cited line: `` `L012345` 09:46:00 service LEVEL message ``
   - `## Other hypotheses` (if any) · `## Red herrings considered` · `## Five whys` · `## Open questions`
3. **`timeline.md`** — a Mermaid timeline built from `work/summary.json` (`changes`, `top_events`). Keep ≤ 15 entries, times in UTC:
   ````
   ```mermaid
   timeline
       title Incident timeline (UTC)
       09:45 : D204 deploy notification-service
       09:46 : First KeyError in template renderer [L000812]
   ```
   ````
4. **`postmortem.md`** — fill `assets/postmortem-engineering.md` (LOAD it). Blameless: describe systems and decisions, never blame people. Owners are placeholders (`_owner_`). If `status` is `insufficient_evidence`, write a short "No root cause established" note listing what was checked and suggested next data to collect, instead of the full template.

## Citation rules (the evidence check enforces these)
- Every sentence that states a cause ("root cause", "caused by", "because", "due to", "led to", "triggered by") must contain at least one line ID like `[L012345]` on the same line.
- Use only line IDs you fetched with `../log-parser/scripts/get_lines.py` or saw in `work/summary.json`.
- Quote log text exactly as printed; it is already redacted. Never try to reconstruct a `[REDACTED:…]` value.
- Numbers (counts, durations, peaks) come from `work/summary.json`, not estimates.

## Then
Run `python scripts/render_report.py <output_dir>` (or let `../run-incident-analysis/scripts/finalize_incident.py` do it together with the evidence check). It builds `report.html`: one offline page with the error chart, change markers, evidence lines, five whys, red herrings and the safety summary.

Audience: `engineering` (default) uses the template as is; `executive` keeps Summary, Impact, Root cause (one paragraph, no jargon) and Action items only.
