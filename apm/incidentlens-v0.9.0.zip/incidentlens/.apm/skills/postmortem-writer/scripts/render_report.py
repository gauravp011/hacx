"""Render a single self-contained report.html for an IncidentLens run.

Usage:
    python render_report.py <output_dir>

Reads evidence.json, work/summary.json, work/timeline.json, work/parsed.jsonl, redaction-report.json and
(optionally) evidence-check.json. Writes <output_dir>/report.html: inline SVG chart, no JavaScript,
no external URLs, light/dark aware, opens offline. Python 3.10+ standard library only.
"""
from __future__ import annotations

import argparse
import html
import json
import math
import re
import sys
from pathlib import Path

PALETTE = ["#D85A30", "#534AB7", "#1D9E75", "#BA7517", "#378ADD", "#D4537E", "#639922", "#888780"]


def _load(p: Path, default=None):
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else default


def _lines(output_dir: Path, ids: set[str]) -> dict[str, dict]:
    out: dict[str, dict] = {}
    p = output_dir / "work" / "parsed.jsonl"
    if not p.exists() or not ids:
        return out
    with open(p, encoding="utf-8") as fh:
        for raw in fh:
            m = re.search(r'"line_id":"(L\d+)"', raw)
            if m and m.group(1) in ids:
                out[m.group(1)] = json.loads(raw)
    return out


def chart(timeline: dict, focus: str | None) -> str:
    mins, series = timeline["minutes"], timeline["series"]
    svcs = [s for s in series if sum(series[s]["error"]) + sum(series[s]["warn"]) > 0] or list(series)
    use_err = any(sum(series[s]["error"]) for s in svcs)
    key = "error" if use_err else "warn"
    W, H, L, B, T = 760, 230, 44, 26, 22
    peak = max([max(series[s][key]) for s in svcs] + [1])
    n = max(1, len(mins) - 1)
    x = lambda i: L + i * (W - L - 12) / n  # noqa: E731
    top = math.log10(peak + 1)
    y = lambda v: H - B - math.log10(v + 1) * (H - B - T) / top  # noqa: E731  (log scale: quiet causes stay visible)
    out = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="{"Errors" if use_err else "Warnings"} per minute by service, log scale">']
    for v in [0] + [10 ** k for k in range(0, 6) if 10 ** k <= peak]:
        out.append(f'<line x1="{L}" x2="{W-12}" y1="{y(v):.1f}" y2="{y(v):.1f}" class="grid"/>'
                   f'<text x="{L-6}" y="{y(v)+4:.1f}" text-anchor="end" class="ax">{v}</text>')
    step = max(1, len(mins) // 8)
    for i in range(0, len(mins), step):
        out.append(f'<text x="{x(i):.1f}" y="{H-8}" text-anchor="middle" class="ax">{mins[i][11:16]}</text>')
    for k, c in enumerate(timeline.get("changes", [])):
        m = c["ts"][:16]
        if m in mins:
            i = mins.index(m)
            out.append(f'<line x1="{x(i):.1f}" x2="{x(i):.1f}" y1="{T-8}" y2="{H-B}" class="deploy"/>'
                       f'<text x="{x(i)+4:.1f}" y="{T-10 + (k % 2) * 11:.1f}" class="dl">{html.escape(c["event_id"])}</text>')
    for j, s in enumerate(svcs):
        pts = " ".join(f"{x(i):.1f},{y(v):.1f}" for i, v in enumerate(series[s][key]))
        out.append(f'<polyline points="{pts}" fill="none" stroke="{PALETTE[j % len(PALETTE)]}" '
                   f'stroke-width="{2.6 if s == focus else 1.4}" stroke-linejoin="round"/>')
    out.append("</svg>")
    legend = "".join(f'<span class="lg"><i style="background:{PALETTE[j % len(PALETTE)]}"></i>{html.escape(s)}'
                     f'{" (root cause)" if s == focus else ""}</span>' for j, s in enumerate(svcs))
    return "".join(out) + f'<div class="legend">{legend}</div>', ("Errors" if use_err else "Warnings")


def render(output_dir: Path) -> Path:
    ev = _load(output_dir / "evidence.json")
    if ev is None:
        raise SystemExit("Missing evidence.json")
    summary = _load(output_dir / "work" / "summary.json", {})
    timeline = _load(output_dir / "work" / "timeline.json", {"minutes": [], "series": {}})
    red = _load(output_dir / "redaction-report.json", {"counts": {}, "total_redacted": 0})
    chk = _load(output_dir / "evidence-check.json")
    hyps = ev.get("hypotheses") or []
    top = hyps[0] if hyps else None
    ids = {i for h in hyps for i in h.get("evidence_line_ids", [])}
    ids |= {i for r in ev.get("red_herrings_considered", []) for i in r.get("line_ids", [])}
    lines = _lines(output_dir, ids)
    esc = html.escape

    def line_html(i: str) -> str:
        r = lines.get(i)
        if not r:
            return f'<div class="ln"><code>{esc(i)}</code> <span class="mut">(line not found)</span></div>'
        return (f'<div class="ln"><code>{esc(i)}</code> <span class="mut">{esc(r["ts"][11:19])}</span> '
                f'<b>{esc(r["service"])}</b> <span class="mut">{esc(str(r.get("host", "")))}</span> '
                f'<span class="lv {esc(r["level"])}">{esc(r["level"])}</span> {esc(r["msg"])}</div>')

    if chk is None:
        badge = '<span class="badge warn">Evidence check not run</span>'
    elif chk["passed"]:
        badge = '<span class="badge ok">Evidence check passed</span>'
    else:
        badge = '<span class="badge bad">Evidence check failed</span>'
    if ev.get("status") == "insufficient_evidence" or not top:
        title = ev.get("incident_title") or "No root cause established: evidence is insufficient"
        conf = '<span class="badge warn">insufficient evidence</span>'
    else:
        title = ev.get("incident_title") or top["summary"].split(". ")[0]
        conf = f'<span class="badge hi">confidence: {esc(top["confidence"])}</span>'
    w = summary.get("window", ["", ""])
    svg, metric = chart(timeline, top["service"] if top else None) if timeline.get("minutes") else ("", "")

    kpis = ""
    if top:
        kpis = (f'<div class="row"><div class="kpi"><span class="mut">Root cause</span><b class="sm">{esc(top["root_cause_id"])}</b></div>'
                f'<div class="kpi"><span class="mut">Service</span><b>{esc(top["service"])}</b></div>'
                f'<div class="kpi"><span class="mut">Trigger</span><b>{esc(", ".join(top.get("related_event_ids") or []) or "none found")}</b></div>'
                f'<div class="kpi"><span class="mut">Lines analysed</span><b>{summary.get("lines", 0):,}</b></div></div>'
                f'<p>{esc(top["summary"])}</p>')
        if ev.get("affected_hosts"):
            kpis += f'<p class="mut">Affected hosts only: <b>{esc(", ".join(ev["affected_hosts"]))}</b></p>'
    else:
        kpis = f'<p>{esc(ev.get("summary", "No anomaly stood out clearly from normal behaviour, so no cause is claimed."))}</p>'

    others = "".join(
        f'<li><b>#{h["rank"]} {esc(h["root_cause_id"])}</b> in {esc(h["service"])} '
        f'<span class="mut">({esc(h["confidence"])})</span><br>{esc(h["summary"])}'
        f'{"".join(line_html(i) for i in h.get("evidence_line_ids", [])[:3])}</li>' for h in hyps[1:])
    whys = "".join(f"<li>{esc(w if isinstance(w, str) else w.get('why', ''))}</li>" for w in ev.get("five_whys", []))
    herr = "".join(f'<li><b>{esc(r.get("what", "Candidate"))}</b><br><span class="mut">{esc(r.get("reason", ""))}</span>'
                   f'{"".join(line_html(i) for i in r.get("line_ids", [])[:2])}</li>'
                   for r in ev.get("red_herrings_considered", []))
    redc = " · ".join(f"{esc(k.replace('_', ' ').lower())} ×{v}" for k, v in red.get("counts", {}).items())
    order = ""
    if summary.get("services_by_error_volume"):
        order = (f'<p class="mut sm2">Loudest service: <b>{esc(summary["services_by_error_volume"][0])}</b>. '
                 f'IncidentLens follows the earliest anomaly in the failing dependency chain, not the loudest one.</p>')
    unver = ""
    if chk and chk.get("unverified_claims"):
        unver = "<ul>" + "".join(f"<li class='mut'>{esc(c)}</li>" for c in chk["unverified_claims"][:8]) + "</ul>"

    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>IncidentLens report</title>
<style>
:root{{--bg:#fafaf8;--card:#fff;--tx:#1f1f1d;--mut:#6b6a65;--bd:#e4e2da;--ac:#534AB7}}
@media(prefers-color-scheme:dark){{:root{{--bg:#1c1c1b;--card:#262624;--tx:#f0efe9;--mut:#a8a69e;--bd:#3a3a37;--ac:#AFA9EC}}}}
body{{margin:0;background:var(--bg);color:var(--tx);font:15px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{max-width:900px;margin:0 auto;padding:28px 20px 60px}}
h1{{font-size:22px;font-weight:500;margin:4px 0 8px}} h2{{font-size:16px;font-weight:500;margin:0 0 10px}}
.card{{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:18px 20px;margin-top:16px}}
.mut{{color:var(--mut)}} .sm2{{font-size:13px}} .row{{display:flex;gap:12px;flex-wrap:wrap}}
.kpi{{flex:1;min-width:150px;background:var(--bg);border-radius:8px;padding:10px 14px}}
.kpi>b{{display:block;font-size:20px;font-weight:500}} .kpi>b.sm{{font-size:15px;word-break:break-word}}
.badge{{font-size:12px;padding:3px 10px;border-radius:8px;margin-right:6px}}
.ok{{background:#EAF3DE;color:#27500A}} .bad{{background:#FCEBEB;color:#791F1F}}
.warn{{background:#FAEEDA;color:#633806}} .hi{{background:#EEEDFE;color:#3C3489}}
.ln{{font:12.5px/1.5 ui-monospace,Consolas,monospace;padding:4px 0;border-bottom:1px dashed var(--bd);word-break:break-word}}
.ln code{{color:var(--ac)}} .lv{{font-size:11px;padding:0 5px;border-radius:4px}}
.ERROR,.FATAL{{background:#FCEBEB;color:#791F1F}} .WARN{{background:#FAEEDA;color:#633806}}
svg{{width:100%;height:auto}} .grid{{stroke:var(--bd)}} .ax{{font-size:10px;fill:var(--mut)}}
.deploy{{stroke:var(--ac);stroke-dasharray:4 3}} .dl{{font-size:10px;fill:var(--ac)}}
.legend{{font-size:12px;color:var(--mut);margin-top:6px}} .lg{{margin-right:14px;white-space:nowrap}}
.lg i{{display:inline-block;width:10px;height:3px;margin-right:5px;vertical-align:middle}}
ul,ol{{padding-left:20px}} li{{margin-bottom:10px}} summary{{cursor:pointer;color:var(--ac)}}
.note{{font-size:12px;color:var(--mut);margin-top:24px}}
</style></head><body><main>
<div class="mut sm2">IncidentLens · incident report · {esc(w[0][:16].replace("T", " "))} – {esc(w[1][11:16])} UTC</div>
<h1>{esc(title)}</h1><div>{badge}{conf}</div>
<div class="card">{kpis}</div>
{f'<div class="card"><h2>{metric} per minute by service <span class="mut sm2">(log scale)</span></h2>{svg}{order}</div>' if svg else ''}
{f'<div class="card"><h2>Evidence (cited log lines)</h2>{"".join(line_html(i) for i in top.get("evidence_line_ids", []))}<p class="mut sm2">Every claim cites a log line ID. {chk["citations_checked"] if chk else 0} citations checked, {len(chk["invalid_line_ids"]) if chk else 0} invalid, {len(chk["unverified_claims"]) if chk else 0} statements without a citation.</p>{unver}</div>' if top else ''}
{f'<div class="card"><h2>Five whys</h2><ol>{whys}</ol></div>' if whys else ''}
{f'<div class="card"><h2>Other hypotheses</h2><ul>{others}</ul></div>' if others else ''}
{f'<div class="card"><h2>Red herrings considered and rejected</h2><ul>{herr}</ul></div>' if herr else ''}
<div class="card"><h2>Safety</h2><div class="row">
<div class="kpi"><span class="mut">Values redacted before analysis</span><b>{red.get("total_redacted", 0)}</b><div class="sm2 mut" style="margin-top:6px">{redc}</div></div>
<div class="kpi"><span class="mut">Secrets found in outputs</span><b>{len(chk["leaked_secret_categories"]) if chk else "not checked"}</b><span class="mut sm2">Leak scan over every output file.</span></div>
</div></div>
<details class="card"><summary>Files in this report</summary><p class="mut">rca.md · timeline.md · postmortem.md · evidence.json · evidence-check.json · redaction-report.json · work/summary.json</p></details>
<p class="note">Generated by IncidentLens. Log values were redacted before analysis. Review before sharing: this is a draft for humans to confirm.</p>
</main></body></html>"""
    out = output_dir / "report.html"
    out.write_text(doc, encoding="utf-8")
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("output_dir")
    a = ap.parse_args(argv)
    print(f"Report written: {render(Path(a.output_dir))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
