# Failure-pattern library

General site-reliability knowledge used to classify a root cause. Classify by the **mechanism that broke**, not by what triggered it: a configuration change that shrinks a connection pool is `DB_POOL_EXHAUSTION`; a deploy that introduces a crash is `BAD_DEPLOY_CODE_ERROR`. Teams can extend this file with their own patterns.

Each pattern lists: signatures, usual triggers, how to tell it apart from look-alikes, device/embedded variants and typical remediation.

---

## DB_POOL_EXHAUSTION
**Signatures:** "timeout acquiring connection", "pool exhausted", "active=N/N", "waiting=…", "could not get JDBC connection", requests stuck for exactly the pool timeout (often 5 s / 30 s). Latency jumps to the timeout value, not gradually.
**Usual triggers:** pool size reduced in config; traffic increase; a slow query or lock holding connections; connection leak after a deploy.
**Tell apart from:** `DEPENDENCY_LATENCY` (the database itself is slow: slow-query logs, rising DB latency before pool errors). In pool exhaustion the database is healthy and the waiting happens inside the application. Look for "active=max/max".
**Embedded variant:** fixed-size buffer/socket/handle pools on gateways ("no free buffers", "socket pool full").
**Remediation:** restore pool size; fix the leak or slow query; add alerting on pool wait time; validate pool settings in config review.

## BAD_DEPLOY_CODE_ERROR
**Signatures:** new exception types (NullPointerException, KeyError, TypeError, segfault, decoder/parsing/protocol errors) that did not exist before; errors concentrated on one endpoint, message type or code path; stack traces pointing to new code.
**Usual triggers:** application deploy, firmware/OTA update, feature-flag flip, schema change.
**Tell apart from:** `MEMORY_LEAK` (gradual onset, restarts), config/pool issues (timeouts rather than exceptions). Key test: did a *new* error template start within minutes of a deploy on the same service? Partial rollouts show errors **only on the updated hosts**: compare affected hosts with the rollout list.
**Embedded variant:** firmware update on a subset of devices/gateways; watchdog resets; decoder/protocol errors from one message type.
**Remediation:** roll back or halt the rollout; fix the code path; add the failing case to tests; use staged/canary rollouts.

## MEMORY_LEAK
**Signatures:** heap/RSS usage rising over time ("heap usage 85%… 92%… 97%"); long GC pauses; OutOfMemoryError / OOM-killer / exit code 137; **periodic restarts** at a regular interval; errors in bursts that align with restarts.
**Usual triggers:** a deploy introducing unbounded caches, listener leaks, unclosed resources.
**Tell apart from:** `BAD_DEPLOY_CODE_ERROR` (errors start immediately and continuously). A leak takes time to build up and shows a saw-tooth: degrade → crash → recover → degrade.
**Embedded variant:** devices rebooting at regular intervals; free-memory telemetry trending down.
**Remediation:** roll back; restart as a stop-gap; heap dump and fix; add memory alerts with trend detection.

## CERT_EXPIRY
**Signatures:** "certificate has expired", "TLS handshake failed", "x509", "notAfter=…", "PKIX path validation failed", "SSL routines". Failures start **at a sharp moment** (often on the hour) and are total for that connection.
**Usual triggers:** none in the change log: it is time-based. Expiry of a server, client or intermediate certificate.
**Tell apart from:** network problems (connection refused/timeouts, not handshake errors) and `DEPENDENCY_LATENCY` (gradual). A deploy shortly before is often a red herring; check whether the error text mentions certificates.
**Embedded variant:** device certificates for MQTT/TLS expiring; clock drift on devices making valid certificates look expired.
**Remediation:** renew/rotate the certificate; add expiry monitoring 30/14/7 days ahead; automate rotation.

## DEPENDENCY_LATENCY
**Signatures:** upstream latency rising (p95/p99 numbers increase), timeouts to one dependency, retries ("attempt 2/3"), circuit breaker OPEN, 504s at the edge. Onset is **gradual** and first visible in the service that calls the slow dependency.
**Usual triggers:** infra event at the provider (failover, region change, network degradation), dependency overload.
**Tell apart from:** `DB_POOL_EXHAUSTION` (timeouts are inside the app's pool, no upstream latency messages); `CERT_EXPIRY` (sharp, handshake errors). Retry storms can make the caller look like the cause: follow the latency numbers to the slowest dependency.
**Embedded variant:** cellular/backhaul link degradation; slow cloud ingest endpoint.
**Remediation:** fail over / route around; tune timeouts and retry budgets with backoff; add dependency latency SLOs.

## DISK_FULL
**Signatures:** "No space left on device", ENOSPC, write failures, log rotation failures, database refusing writes, crash loops after the disk fills. Often preceded by a **surge in log volume** (e.g. DEBUG logging enabled).
**Usual triggers:** log level raised to DEBUG/TRACE; log rotation broken; temp files or dumps accumulating.
**Tell apart from:** crashes from `MEMORY_LEAK` (exit 137 without ENOSPC); code errors. Check for a volume surge that started earlier on the same service.
**Embedded variant:** flash storage full on devices; ring-buffer logs not rotating.
**Remediation:** free space and restore log level; enforce rotation and quotas; alert on disk usage and log-volume anomalies.

## UNKNOWN
Use when a real anomaly exists but no pattern fits with reasonable confidence. Describe what was observed and cite it; do not force-fit a pattern.

---

## When not to name a cause
Return `status: "insufficient_evidence"` (no hypotheses, or only low-confidence `UNKNOWN`) when:
- no notable cluster stands out from normal behaviour beyond short, self-limiting bursts;
- warnings are isolated, low volume and have no downstream effect in the service map;
- evidence conflicts and you cannot tell which anomaly explains the reported symptom.
Saying "no incident found" is a correct and valuable answer.

## Common red herrings
- **The loudest service** is usually where users notice the problem (edge/gateway), not where it started.
- **Short bursts that end on their own** (a burst of 404s, a brief retry blip) before or during an incident.
- **A change that happened** near the incident but on an unrelated service or with no new error template after it.
- **Errors from one client or endpoint unrelated to the reported symptom** (e.g. rate limiting on a different endpoint).
- **Steady background warnings** that were present before the incident at the same rate.
