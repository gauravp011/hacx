---
name: rca-reasoning
description: Use when you need to find the most likely root cause of an incident from IncidentLens parser outputs (summary.json, clusters.json, timeline.json). Ranks evidence-backed hypotheses, rejects red herrings and says "insufficient evidence" instead of guessing.
---

# RCA reasoning

You decide **why** the incident happened. Python has already counted everything; you reason over its outputs and cite exact log lines. You never read raw or redacted log files directly.

## Inputs (in the run's output folder, default `incident-report/`)
- `work/summary.json` — read this first. Services ordered by first anomaly and by error volume, notable clusters with hosts and nearby changes, changes, service map, top events.
- `work/clusters.json` — every message template with counts and sample line IDs (open only if you need a cluster not in the summary).
- `work/timeline.json` — per-minute counts (open only to check a shape: gradual, sharp, saw-tooth, surge).
- The user's symptom text, if given.
- `references/failure-patterns.md` — LOAD it before classifying.

To see actual lines, run the log-parser skill's script (sibling folder):
```
python ../log-parser/scripts/get_lines.py <output_dir> --cluster C006
python ../log-parser/scripts/get_lines.py <output_dir> --ids L012517,L013763
python ../log-parser/scripts/get_lines.py <output_dir> --around L012517 --n 5
```
Paths are relative to this skill's folder; from the workspace use the installed path, e.g. `.kiro/skills/log-parser/scripts/get_lines.py`.

## Reasoning steps (follow in order, keep notes short)
1. **Symptom.** What do users see, and in which service? (User's symptom text, else the edge service with the most errors.)
2. **Dependency chain.** Using `service_map` (caller → callees), list the services the symptom service depends on, directly and indirectly. Only anomalies in this chain can explain the symptom.
3. **Earliest anomaly in the chain, not the loudest.** Compare `services_by_first_anomaly` with `services_by_error_volume`. For each chain service, take the onset of its notable ERROR/FATAL clusters (WARN if that's all it has), and any log-volume surge. The root cause is usually the most downstream service whose anomaly starts first; the services that call it fail later.
4. **Changes.** Look for changes within 15 minutes **before** that onset (`nearby_changes`). A matching change on the same service is strong evidence. No change at all is normal for time-based failures (certificates).
5. **Scope.** If `only_on_hosts` is set, the fault is limited to those hosts. Check whether they match a partial rollout in the change details. Report them in `affected_hosts`.
6. **Classify.** Match the causal cluster's message and the timeline shape (sharp, gradual, saw-tooth, surge) against `references/failure-patterns.md`. Classify by mechanism, not trigger.
7. **Evidence.** For the top hypothesis, fetch and cite 2–4 lines: the first causal error, a representative later causal line, and the first downstream symptom. Only cite IDs you have seen in script output.
8. **Red herrings.** For every other notable cluster, state in one sentence why it is not the cause (ended before the fault, not in the dependency chain, unrelated endpoint/client, present before at the same rate, no downstream effect).
9. **Five whys** for the top hypothesis, each step citing a line ID or change ID where possible.
10. **Confidence.** high = matching change + clear onset order + pattern fit; medium = two of these; low = one. If nothing stands out or evidence conflicts, return `insufficient_evidence` with no hypotheses (or one low-confidence `UNKNOWN`) and explain what you checked.

## Output
Return (or write, when asked) a JSON object in this shape; postmortem-writer saves it as `evidence.json`:
```json
{
  "status": "ok",
  "incident_title": "Order e-mails failing after notification-service release",
  "hypotheses": [
    {"rank": 1, "root_cause_id": "BAD_DEPLOY_CODE_ERROR", "service": "notification-service",
     "summary": "Release D204 introduced a KeyError in the e-mail template renderer; errors began 1 min after the deploy and the mail queue backed up.",
     "confidence": "high", "evidence_line_ids": ["L000812", "L001377", "L000851"], "related_event_ids": ["D204"]}
  ],
  "affected_hosts": null,
  "red_herrings_considered": [
    {"what": "cdn-edge 404 burst for an old image", "line_ids": ["L000120"],
     "reason": "Ended 20 min before the fault and is not in the notification dependency chain."}
  ],
  "five_whys": ["Why were e-mails not sent? The mail queue rejected messages that failed to render [L000851].", "..."],
  "unverified_claims": []
}
```
Rules: `root_cause_id` ∈ {DB_POOL_EXHAUSTION, BAD_DEPLOY_CODE_ERROR, MEMORY_LEAK, CERT_EXPIRY, DEPENDENCY_LATENCY, DISK_FULL, UNKNOWN}. `status` ∈ {ok, insufficient_evidence}. `confidence` ∈ {high, medium, low}. Up to `max_hypotheses` (default 3), ranked. Never invent line IDs or change IDs.

## Do not
- Do not open `*.jsonl` log files or paste large outputs into the conversation.
- Do not pick the service with the most errors just because it is loudest.
- Do not use information outside the provided files (no answer keys, no guesses about other systems).
- Do not suggest or perform remediation actions on any system. Recommendations go in the post-mortem only.
