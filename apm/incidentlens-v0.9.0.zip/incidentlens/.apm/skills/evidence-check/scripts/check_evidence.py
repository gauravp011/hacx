"""Check that an IncidentLens report is backed by evidence and leaks nothing.

Usage:
    python check_evidence.py <output_dir> [--deploys deploys.json]

Checks:
  1. evidence.json structure (status, hypotheses, confidence, taxonomy ids) - stdlib validation
  2. every cited line_id exists in <output_dir>/work/parsed.jsonl (the redacted logs)
  3. related_event_ids exist in deploys.json (when given)
  4. root-cause sentences in rca.md / postmortem.md without a line-ID reference -> unverified_claims
  5. leak scan: no secret-like strings in any output file (uses the redact-logs detectors)
Writes <output_dir>/evidence-check.json (never contains secret values).
Exit code 0 = passed, 1 = failed (top hypothesis has no valid evidence, invalid IDs, schema errors or leaks).
Unverified claims are reported as warnings; they fail the check only with --strict-claims.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[2] / "redact-logs" / "scripts"))
try:
    from redact import find_leaks  # type: ignore  # noqa: E402
except ImportError:  # redact-logs skill missing: leak scan cannot run
    find_leaks = None

TAXONOMY = {"DB_POOL_EXHAUSTION", "BAD_DEPLOY_CODE_ERROR", "MEMORY_LEAK", "CERT_EXPIRY", "DEPENDENCY_LATENCY",
            "DISK_FULL", "UNKNOWN"}
CLAIM = re.compile(r"\b(root cause|caused by|because|due to|triggered by|led to|resulted in|was the cause)\b", re.I)
LINE_REF = re.compile(r"\bL\d{6,}\b")


def validate(ev: dict) -> list[str]:
    """Return a list of structural problems in evidence.json."""
    errs = []
    if ev.get("status") not in ("ok", "insufficient_evidence"):
        errs.append("status must be 'ok' or 'insufficient_evidence'")
    hyps = ev.get("hypotheses")
    if not isinstance(hyps, list):
        return errs + ["hypotheses must be a list"]
    if ev.get("status") == "ok" and not hyps:
        errs.append("status 'ok' needs at least one hypothesis")
    for i, h in enumerate(hyps):
        p = f"hypotheses[{i}]"
        if not isinstance(h, dict):
            errs.append(f"{p} must be an object")
            continue
        if h.get("root_cause_id") not in TAXONOMY:
            errs.append(f"{p}.root_cause_id '{h.get('root_cause_id')}' not in taxonomy")
        if h.get("confidence") not in ("high", "medium", "low"):
            errs.append(f"{p}.confidence must be high|medium|low")
        for key in ("service", "summary"):
            if not isinstance(h.get(key), str) or not h.get(key):
                errs.append(f"{p}.{key} must be a non-empty string")
        if not isinstance(h.get("evidence_line_ids"), list):
            errs.append(f"{p}.evidence_line_ids must be a list")
        if not isinstance(h.get("rank"), int):
            errs.append(f"{p}.rank must be an integer")
    return errs


def scan_claims(text: str, name: str) -> list[str]:
    out, in_actions = [], False
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("#"):
            in_actions = "action" in s.lower()
            continue
        if in_actions or not s or s.startswith("|---") or s.startswith("```"):
            continue
        for sentence in re.split(r"(?<=[.!?])\s+", s):
            if CLAIM.search(sentence) and not LINE_REF.search(sentence) and not LINE_REF.search(s):
                out.append(f"{name}: {sentence[:160]}")
    return out


def run(output_dir: Path, deploys: Path | None = None, strict_claims: bool = False,
        skip: tuple[str, ...] = ()) -> dict:
    ev_path = output_dir / "evidence.json"
    if not ev_path.exists():
        raise SystemExit(f"Missing {ev_path}")
    try:
        ev = json.loads(ev_path.read_text(encoding="utf-8"))
    except ValueError as e:
        ev, schema_errors = {}, [f"evidence.json is not valid JSON: {e}"]
    else:
        schema_errors = validate(ev)
    known: set[str] = set()
    parsed = output_dir / "work" / "parsed.jsonl"
    if parsed.exists():
        with open(parsed, encoding="utf-8") as fh:
            for raw in fh:
                m = re.search(r'"line_id":"(L\d+)"', raw)
                if m:
                    known.add(m.group(1))
    hyps = ev.get("hypotheses") or []
    cited = [i for h in hyps if isinstance(h, dict) for i in (h.get("evidence_line_ids") or [])]
    cited += [i for r in ev.get("red_herrings_considered") or [] for i in (r.get("line_ids") or [])]
    invalid = sorted({i for i in cited if i not in known})
    bad_events: list[str] = []
    if deploys and deploys.exists():
        ids = {d.get("event_id") for d in json.loads(deploys.read_text(encoding="utf-8"))}
        bad_events = sorted({e for h in hyps if isinstance(h, dict) for e in (h.get("related_event_ids") or [])
                             if e not in ids})
    unverified = []
    for name in ("rca.md", "postmortem.md"):
        p = output_dir / name
        if p.exists():
            unverified += scan_claims(p.read_text(encoding="utf-8"), name)
    leaks: set[str] = set()
    scanned = []
    if find_leaks:
        for f in sorted(output_dir.iterdir()):
            if f.is_file() and f.suffix in (".md", ".json", ".html", ".txt") and f.name not in skip \
                    and f.name not in ("redaction-report.json", "evidence-check.json"):
                leaks |= find_leaks(f.read_text(encoding="utf-8"))
                scanned.append(f.name)
    top_valid = bool(hyps) and any(i in known for i in (hyps[0].get("evidence_line_ids") or []))
    status = ev.get("status")
    evidence_ok = top_valid or (status == "insufficient_evidence")
    passed = (evidence_ok and not invalid and not schema_errors and not leaks and not bad_events
              and (not strict_claims or not unverified))
    result = {
        "passed": passed, "status_reported": status, "citations_checked": len(cited),
        "top_hypothesis_has_valid_evidence": top_valid, "invalid_line_ids": invalid,
        "unknown_event_ids": bad_events, "schema_errors": schema_errors, "unverified_claims": unverified,
        "leaked_secret_categories": sorted(leaks), "files_leak_scanned": scanned,
        "leak_scan": "ran" if find_leaks else "skipped: redact-logs skill not found",
    }
    (output_dir / "evidence-check.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("output_dir")
    ap.add_argument("--deploys")
    ap.add_argument("--strict-claims", action="store_true")
    a = ap.parse_args(argv)
    r = run(Path(a.output_dir), Path(a.deploys) if a.deploys else None, a.strict_claims)
    print(f"Evidence check {'PASSED' if r['passed'] else 'FAILED'}: {r['citations_checked']} citations, "
          f"{len(r['invalid_line_ids'])} invalid, {len(r['unverified_claims'])} unverified claims, "
          f"leaks: {r['leaked_secret_categories'] or 'none'}")
    for c in r["unverified_claims"][:10]:
        print(f"  unverified: {c}")
    for e in r["schema_errors"]:
        print(f"  schema: {e}")
    return 0 if r["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
