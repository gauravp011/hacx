---
name: evidence-check
description: Use after writing an incident RCA or post-mortem to verify every claim cites real log lines, evidence.json is well formed, and no secrets leaked into any output.
---

# Evidence check

Final safety step of IncidentLens.

## Command
```
python scripts/check_evidence.py <output_dir> [--deploys <output_dir>/work/deploys.json] [--strict-claims]
```
Usually run for you by `../run-incident-analysis/scripts/finalize_incident.py`.

## What it checks
1. `evidence.json` structure: `status` (`ok`/`insufficient_evidence`), ranked hypotheses, taxonomy `root_cause_id`, `confidence`.
2. Every cited `line_id` exists in the redacted, parsed logs.
3. Every `related_event_ids` entry exists in the deploys file (when given).
4. Sentences in `rca.md` / `postmortem.md` that state a cause ("root cause", "caused by", "because", "due to", "led to"…) without a line ID → `unverified_claims`.
5. Leak scan: every output file is re-scanned with the redact-logs detectors.

Writes `<output_dir>/evidence-check.json` (no secret values). Exit 0 = passed; 1 = failed (top hypothesis without valid evidence, invalid IDs, schema errors or leaks). Unverified claims are warnings unless `--strict-claims` is used.

## When it fails
- Invalid line IDs → fetch real ones with `../log-parser/scripts/get_lines.py` and fix the files.
- Unverified claims → add the supporting line ID to the sentence, or remove the claim.
- Leaks → delete the leaked text from the output file.
Then run it again. Report the final result to the user honestly.
