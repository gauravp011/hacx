---
name: redact-logs
description: Use before any AI reads log data - masks secrets and personal data (emails, IPs, tokens, JWTs, passwords, API keys, long hex/base64 secrets, card numbers) in JSONL logs and writes a counts-only report.
---

# Redact logs

First safety step of IncidentLens. Nothing else reads logs until this has run.

## Command
```
python scripts/redact.py <jsonl_logs_dir> <output_dir>/work/redacted [--mode strict|standard]
```
- Input: a folder of IncidentLens JSONL files (use `../log-parser/scripts/convert_logs.py` first for other formats).
- Output: redacted copies with the same names and line order, plus `<output_dir>/redaction-report.json` with **counts per category only**, never the values.
- `strict` (default) masks every IP address; `standard` keeps private IPv4 ranges. There is no "off" mode.
- On failure (missing folder, no files) it exits non-zero with a message. **Stop the workflow; never continue on unredacted logs.**

## What gets masked
| Category | Examples (fictional) |
|---|---|
| EMAIL | `jane.doe@example.test` |
| IPV4 / IPV6 | `10.20.30.41`, `fd12:3456:789a::1f2e` |
| BEARER_TOKEN | `Authorization: Bearer FAKE-tok-…` |
| JWT | `eyJhbGciOi….eyJzdWIi….sig` |
| KEY_VALUE_SECRET | `password=…`, `api_key=…`, `secret=…`, `token=…` |
| HEX_SECRET | 32+ hex characters |
| BASE64_SECRET | 40+ base64 characters containing digits and capitals |
| CARD_NUMBER | 13–19 digits that pass the Luhn check |

Each value becomes `[REDACTED:<CATEGORY>]`. Structural fields (`line_id`, `ts`, `level`, `service`, `trace_id`, `http_status`, `latency_ms`) are never changed, so evidence line IDs stay valid. Version strings like `v2.4.1`, ports and short trace IDs are not masked.

## Limitations
Pattern-based: names of people, street addresses and secrets in unusual formats can slip through. The evidence-check skill re-scans every output with the same detectors. Tell users to review outputs before sharing.
