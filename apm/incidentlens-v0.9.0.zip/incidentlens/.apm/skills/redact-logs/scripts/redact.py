"""Redact secrets and personal data from JSONL logs before any analysis.

Usage:
    python redact.py <logs_dir> <out_dir> [--mode strict|standard]

Writes redacted copies of every *.jsonl file (same names, same line order) to <out_dir>
and a counts-only report to <out_dir>/../../redaction-report.json (i.e. <output_dir>/redaction-report.json
when <out_dir> is <output_dir>/work/redacted). Secret values are never written to the report.

Python 3.10+ standard library only.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# Order matters: more specific patterns first.
PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("JWT", re.compile(r"\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}")),
    ("BEARER_TOKEN", re.compile(r"\bBearer\s+[A-Za-z0-9\-._~+/]{8,}=*")),
    ("KEY_VALUE_SECRET", re.compile(
        r"(?i)\b(password|passwd|pwd|secret|client_secret|api_key|apikey|access_key|token|auth_token)\s*[=:]\s*(?!\[REDACTED)(?!<)[^\s,;\"'&<>]{3,}")),
    ("EMAIL", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")),
    ("IPV6", re.compile(r"(?<![\w:])(?=[0-9A-Fa-f:]*[A-Fa-f])(?:[0-9A-Fa-f]{1,4}:){1,7}:?(?:[0-9A-Fa-f]{1,4})?(?::[0-9A-Fa-f]{1,4}){0,6}(?![\w:])")),
    ("IPV4", re.compile(r"(?<![\d.])(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)(?![\d.])")),
    ("HEX_SECRET", re.compile(r"\b[0-9a-fA-F]{32,}\b")),
    ("BASE64_SECRET", re.compile(r"(?<![A-Za-z0-9+/=])(?=[A-Za-z0-9+/]*\d)(?=[A-Za-z0-9+/]*[A-Z])[A-Za-z0-9+/]{40,}={0,2}(?![A-Za-z0-9+/=])")),
    ("CARD_NUMBER", re.compile(r"(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)")),
]
PROTECTED_FIELDS = {"line_id", "ts", "level", "service", "trace_id", "http_status", "latency_ms"}
PRIVATE_V4 = re.compile(r"^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.)")


def luhn_ok(candidate: str) -> bool:
    """True if the digits pass the Luhn checksum (credit-card-like)."""
    digits = [int(c) for c in candidate if c.isdigit()]
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _ipv6_ok(text: str) -> bool:
    return text.count(":") >= 2 and ("::" in text or text.count(":") == 7)


def redact_text(text: str, counts: dict[str, int], mode: str = "strict") -> str:
    """Replace every detected secret in text with [REDACTED:<CATEGORY>] and count it."""
    for cat, pat in PATTERNS:
        def repl(m: re.Match[str], cat: str = cat) -> str:
            val = m.group(0)
            if cat == "CARD_NUMBER" and not luhn_ok(val):
                return val
            if cat == "IPV6" and not _ipv6_ok(val):
                return val
            if cat == "IPV4" and mode == "standard" and PRIVATE_V4.match(val):
                return val
            counts[cat] = counts.get(cat, 0) + 1
            return f"[REDACTED:{cat}]"
        text = pat.sub(repl, text)
    return text


def find_leaks(text: str) -> set[str]:
    """Return the secret categories still present in text (used by evidence-check's leak scan)."""
    found: dict[str, int] = {}
    redact_text(text, found, "strict")
    return set(found)


def redact_record(rec: dict, counts: dict[str, int], mode: str) -> dict:
    """Redact every string field except protected structural fields. host is redacted only if it looks sensitive."""
    out = {}
    for k, v in rec.items():
        out[k] = redact_text(v, counts, mode) if isinstance(v, str) and k not in PROTECTED_FIELDS else v
    return out


def run(logs_dir: Path, out_dir: Path, mode: str = "strict") -> dict:
    """Redact all *.jsonl in logs_dir into out_dir. Raises SystemExit with a clear message on failure."""
    if not logs_dir.is_dir():
        raise SystemExit(f"REDACTION FAILED: logs folder not found: {logs_dir}")
    files = sorted(logs_dir.glob("*.jsonl"))
    if not files:
        raise SystemExit(f"REDACTION FAILED: no .jsonl files in {logs_dir}. Run convert_logs.py first for other formats.")
    if out_dir.resolve() == logs_dir.resolve():
        raise SystemExit("REDACTION FAILED: output folder must differ from input folder")
    out_dir.mkdir(parents=True, exist_ok=True)
    counts: dict[str, int] = {}
    lines = bad = 0
    for f in files:
        tmp = out_dir / (f.name + ".part")
        with open(f, encoding="utf-8", errors="replace") as src, open(tmp, "w", encoding="utf-8", newline="\n") as dst:
            for raw in src:
                raw = raw.strip()
                if not raw:
                    continue
                lines += 1
                try:
                    rec = json.loads(raw)
                    if not isinstance(rec, dict):
                        raise ValueError
                except ValueError:
                    bad += 1
                    rec = {"line_id": None, "level": "UNKNOWN", "msg": raw}
                dst.write(json.dumps(redact_record(rec, counts, mode), separators=(",", ":")) + "\n")
        tmp.replace(out_dir / f.name)
    report = {"tool": "incidentlens/redact-logs", "mode": mode, "files": len(files), "lines": lines,
              "unparsable_lines": bad, "counts": dict(sorted(counts.items())), "total_redacted": sum(counts.values())}
    report_path = out_dir.parent.parent / "redaction-report.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Redact secrets/PII from JSONL logs.")
    ap.add_argument("logs_dir")
    ap.add_argument("out_dir")
    ap.add_argument("--mode", choices=["strict", "standard"], default="strict",
                    help="strict (default) also masks private IPs; there is no 'off' mode")
    a = ap.parse_args(argv)
    rep = run(Path(a.logs_dir), Path(a.out_dir), a.mode)
    print(f"Redacted {rep['total_redacted']} values in {rep['files']} files ({rep['lines']} lines). "
          f"By category: {rep['counts'] or 'none'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
