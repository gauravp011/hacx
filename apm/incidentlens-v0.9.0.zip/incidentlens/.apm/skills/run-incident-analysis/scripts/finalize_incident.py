"""Finish a run after the reasoning/writing steps: evidence check -> HTML report -> final leak scan.

Usage:
    python finalize_incident.py [--output-dir ./incident-report]

Exit code 0 when the evidence check passes and no secrets leaked into any output, 1 otherwise.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

SKILLS = Path(__file__).resolve().parents[2]
PY = sys.executable


def run(args: list[str]) -> tuple[int, str]:
    p = subprocess.run([PY, *args], capture_output=True, text=True, encoding="utf-8")
    return p.returncode, (p.stdout + p.stderr).strip()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--output-dir", default="incident-report")
    a = ap.parse_args(argv)
    out = Path(a.output_dir)
    missing = [f for f in ("evidence.json", "rca.md", "postmortem.md") if not (out / f).exists()]
    if missing:
        print(f"STOPPED: missing outputs {missing}. Finish the postmortem-writer step first.")
        return 2
    check = [str(SKILLS / "evidence-check" / "scripts" / "check_evidence.py"), str(out)]
    if (out / "work" / "deploys.json").exists():
        check += ["--deploys", str(out / "work" / "deploys.json")]
    rc, msg = run(check)
    print(msg)
    render = SKILLS / "postmortem-writer" / "scripts" / "render_report.py"
    if render.exists():
        rc2, msg2 = run([str(render), str(out)])
        print(msg2)
        if rc2 == 0:
            rc, msg = run(check)  # re-run so report.html is leak-scanned too
            print("Final " + msg.splitlines()[0])
    print(f"\nOpen {out / 'report.html'} to review. Status: {'PASSED' if rc == 0 else 'NEEDS ATTENTION'}")
    if rc != 0:
        print("Fix: cite valid line IDs for the top hypothesis, remove unsupported claims, then re-run finalize.")
    return 0 if rc == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
