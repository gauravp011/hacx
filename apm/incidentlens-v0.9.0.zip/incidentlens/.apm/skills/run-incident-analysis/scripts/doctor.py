"""Check that IncidentLens can run here. Prints PASS/FAIL with a one-line fix for each problem.

Usage:
    python doctor.py [--logs <file_or_folder>] [--output-dir ./incident-report]
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

SKILLS = Path(__file__).resolve().parents[2]
REQUIRED = {
    "redact-logs": "scripts/redact.py",
    "log-parser": "scripts/parse_logs.py",
    "rca-reasoning": "references/failure-patterns.md",
    "postmortem-writer": "scripts/render_report.py",
    "evidence-check": "scripts/check_evidence.py",
}


def checks(logs: str | None, output_dir: str) -> list[tuple[bool, str, str]]:
    res = [(sys.version_info >= (3, 10), f"Python {sys.version.split()[0]}", "Install Python 3.10 or newer.")]
    for skill, f in REQUIRED.items():
        p = SKILLS / skill / f
        res.append((p.exists(), f"skill {skill}", f"Missing {p}. Re-install the IncidentLens package."))
    if logs:
        p = Path(logs)
        ok = p.exists() and (p.is_file() or any(p.iterdir()))
        res.append((ok, f"logs at {p}", "Check the path; it must be a log file or a non-empty folder."))
        if ok:
            sys.path.insert(0, str(SKILLS / "log-parser" / "scripts"))
            from convert_logs import detect  # noqa: E402
            first = p if p.is_file() else next(x for x in sorted(p.rglob("*")) if x.is_file())
            fmt = detect(first.read_text(encoding="utf-8-sig", errors="replace")[:20000])
            res.append((True, f"log format looks like: {fmt}", ""))
    out = Path(output_dir)
    parent = out if out.exists() else out.parent if str(out.parent) else Path(".")
    res.append((os.access(parent if parent.exists() else Path("."), os.W_OK), f"output folder {out} writable",
                "Choose a writable --output-dir."))
    return res


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--logs")
    ap.add_argument("--output-dir", default="incident-report")
    a = ap.parse_args(argv)
    bad = 0
    for ok, what, fix in checks(a.logs, a.output_dir):
        print(f"{'PASS' if ok else 'FAIL'}  {what}" + ("" if ok else f"  -> {fix}"))
        bad += not ok
    print("Ready." if not bad else f"{bad} problem(s) found.")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
