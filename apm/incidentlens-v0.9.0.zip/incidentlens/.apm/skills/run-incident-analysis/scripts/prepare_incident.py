"""Run every deterministic step before reasoning: check -> convert -> redact -> parse -> cluster -> timeline.

Usage:
    python prepare_incident.py --logs <file_or_folder> [--deploys deploys.json] [--service-map service_map.json]
                               [--output-dir ./incident-report] [--format auto] [--map mapping.json]
                               [--redaction strict|standard] [--time-window START/END] [--min-severity WARN]

Prints a compact briefing for the reasoning step and writes everything under <output-dir>/work/.
Stops with a clear message (non-zero exit) if logs are missing, unparsable, redaction fails or the window is empty.
Unredacted intermediate files are deleted as soon as redaction has finished.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

SKILLS = Path(__file__).resolve().parents[2]
PY = sys.executable


def step(name: str, args: list[str]) -> str:
    """Run one sibling-skill script; stop the pipeline with its message on failure."""
    proc = subprocess.run([PY, *args], capture_output=True, text=True, encoding="utf-8")
    out = (proc.stdout + proc.stderr).strip()
    if proc.returncode != 0:
        print(f"STOPPED at {name}: {out or 'exit code ' + str(proc.returncode)}")
        if proc.returncode == 3:
            print("Next step: inspect the sample lines above, write a mapping file, re-run with --map.")
        sys.exit(proc.returncode or 1)
    print(f"[ok] {name}: {out.splitlines()[-1] if out else ''}")
    return out


def is_incidentlens_jsonl(src: Path) -> bool:
    files = sorted(src.glob("*.jsonl")) if src.is_dir() else ([src] if src.suffix == ".jsonl" else [])
    if not files or (src.is_dir() and any(p.is_file() and p.suffix != ".jsonl" for p in src.iterdir()
                                           if not p.name.startswith("."))):
        return False
    try:
        with open(files[0], encoding="utf-8") as fh:
            first = json.loads(fh.readline())
        return isinstance(first, dict) and str(first.get("line_id", "")).startswith("L") and "ts" in first
    except (ValueError, OSError):
        return False


def briefing(out: Path) -> None:
    s = json.loads((out / "work" / "summary.json").read_text(encoding="utf-8"))
    print("\n=== BRIEFING (read work/summary.json for full detail) ===")
    print(f"Window: {s['window'][0]} .. {s['window'][1]}  lines: {s['lines']}")
    print(f"Services by FIRST anomaly : {s['services_by_first_anomaly']}")
    print(f"Services by ERROR volume  : {s['services_by_error_volume']}")
    if s.get("service_map"):
        print("Service map (caller -> callees): " + "; ".join(f"{k} -> {', '.join(v)}" for k, v in s["service_map"].items()))
    print("Changes: " + ("; ".join(f"{c['event_id']} {c['ts'][11:16]} {c['service']} {c.get('change_type', '')}: "
                                    f"{c.get('details', '')}" for c in s["changes"]) or "none provided"))
    print("Notable clusters (id | service | level | count | first..last | hosts | changes<=15min before | example):")
    for c in s["notable_clusters"]:
        hosts = f"only {','.join(c['only_on_hosts'])}" if c.get("only_on_hosts") else f"{len(c['hosts'])} hosts"
        print(f"  {c['cluster_id']} | {c['service']} | {c['level']} | {c['count']} | {c['first_seen'][11:19]}.."
              f"{c['last_seen'][11:19]} | {hosts} | {','.join(c['nearby_changes']) or '-'} | {c['example'][:80]}")
    for c in s.get("other_error_clusters", []):
        print(f"  {c['cluster_id']} | {c['service']} | {c['level']} | {c['count']} ({c['kind']}) | "
              f"{c['first_seen'][11:19]} | {c['example'][:80]}")
    vol = [x for x in s["services"] if x.get("volume_anomaly_onset")]
    for x in vol:
        ch = ",".join(x.get("changes_before_volume_surge") or []) or "-"
        print(f"  Volume surge: {x['service']} from {x['volume_anomaly_onset'][11:16]} (all levels, incl. DEBUG); "
              f"changes <=15min before: {ch}")
    print("Next: follow the rca-reasoning skill. Fetch evidence with log-parser/scripts/get_lines.py.")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--logs", required=True)
    ap.add_argument("--deploys")
    ap.add_argument("--service-map")
    ap.add_argument("--output-dir", default="incident-report")
    ap.add_argument("--format", default="auto")
    ap.add_argument("--map")
    ap.add_argument("--redaction", choices=["strict", "standard"], default="strict")
    ap.add_argument("--time-window")
    ap.add_argument("--min-severity", default="WARN")
    a = ap.parse_args(argv)

    logs, out = Path(a.logs), Path(a.output_dir)
    if not logs.exists():
        print(f"STOPPED: logs not found at {logs}")
        return 2
    for label, p in (("deploys", a.deploys), ("service map", a.service_map)):
        if p and not Path(p).exists():
            print(f"STOPPED: {label} file not found at {p}")
            return 2
    work = out / "work"
    if work.exists():
        shutil.rmtree(work)
    for f in ("evidence.json", "rca.md", "timeline.md", "postmortem.md", "report.html", "evidence-check.json",
              "redaction-report.json"):
        (out / f).unlink(missing_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    lp = SKILLS / "log-parser" / "scripts"

    src = logs
    converted = work / "converted"
    if not is_incidentlens_jsonl(logs):
        args = [str(lp / "convert_logs.py"), str(logs), str(converted), "--format", a.format]
        if a.map:
            args += ["--map", a.map]
        step("convert", args)
        src = converted
    step("redact", [str(SKILLS / "redact-logs" / "scripts" / "redact.py"), str(src), str(work / "redacted"),
                    "--mode", a.redaction])
    if converted.exists():
        shutil.rmtree(converted)  # never keep unredacted copies
    parse_args = [str(lp / "parse_logs.py"), str(out), "--min-severity", a.min_severity]
    if a.time_window:
        parse_args += ["--time-window", a.time_window]
    step("parse", parse_args)
    step("cluster", [str(lp / "cluster_errors.py"), str(out)])
    tl = [str(lp / "build_timeline.py"), str(out)]
    if a.deploys:
        tl += ["--deploys", a.deploys]
        shutil.copy(a.deploys, work / "deploys.json")
    if a.service_map:
        tl += ["--service-map", a.service_map]
    step("timeline", tl)
    briefing(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
