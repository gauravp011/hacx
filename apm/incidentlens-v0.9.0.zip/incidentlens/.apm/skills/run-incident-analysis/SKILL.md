---
name: run-incident-analysis
description: Use when the user wants to investigate an incident, find the root cause from logs, triage an outage or write a post-mortem from log files. Runs the full IncidentLens pipeline (redact, parse, reason, write, evidence check, HTML report) on a log file or folder.
---

# Run an incident analysis (IncidentLens workflow)

You coordinate five sibling skills: **redact-logs → log-parser → rca-reasoning → postmortem-writer → evidence-check**. Deterministic work is done by two scripts in this skill; you do the reasoning and writing in between.

## Parameters (ask only for `logs` if missing; use defaults otherwise)
| Parameter | Default | Notes |
|---|---|---|
| `logs` | required | log file or folder, any supported format |
| `deploys` | none | JSON list of changes (`event_id, ts, service, change_type, details`) — strongly recommended |
| `service_map` | none | JSON or simple YAML: `caller: [callee, ...]` |
| `symptom` | none | what users reported, e.g. "checkout returns 503" |
| `mode` | `full` | `full` = all outputs; `triage` = top hypothesis only, ≤10 lines, no post-mortem |
| `format` | `auto` | `jsonl, json, csv, cloudwatch, datadog, ecs, plain` |
| `time_window` | auto | `START/END` ISO timestamps |
| `min_severity` | `WARN` | |
| `max_hypotheses` | `3` | |
| `redaction` | `strict` | `strict` or `standard`; it cannot be turned off |
| `output_dir` | `./incident-report` | |
| `audience` | `engineering` | tone of the post-mortem |

Script paths below are relative to this skill's folder. In Kiro they are under `.kiro/skills/`; for other tools look in `.agents/skills/`, `.github/skills/` or `.claude/skills/`. Run with `python` (or `python3`).

## Steps
1. **Prepare (deterministic).**
   ```
   python scripts/prepare_incident.py --logs <logs> [--deploys <deploys>] [--service-map <map>] --output-dir <output_dir> [--format <format>] [--redaction strict] [--time-window ...] [--min-severity WARN]
   ```
   It checks inputs, converts other formats to JSONL, **redacts secrets**, parses, clusters and builds the timeline, then prints a briefing.
   - Exit code 3 = unknown log format. Look at the printed sample lines, write `<output_dir>/mapping.json` (see `../log-parser/SKILL.md`, "Unknown formats"), and re-run with `--map <output_dir>/mapping.json`.
   - Any other `STOPPED` message: report it to the user in plain words and stop. **Never continue on unredacted data and never open the original log files yourself.**
2. **Reason.** Follow `../rca-reasoning/SKILL.md` using the briefing, `work/summary.json` and `get_lines.py`. Use the user's `symptom` in step 1 of that skill.
3. **Write.** Follow `../postmortem-writer/SKILL.md` to write `evidence.json`, `rca.md`, `timeline.md` and `postmortem.md` into `<output_dir>`. In `triage` mode write only `evidence.json` and `rca.md`.
4. **Finalize (deterministic).**
   ```
   python scripts/finalize_incident.py --output-dir <output_dir>
   ```
   Runs the evidence check and builds `report.html`. If it reports invalid line IDs, schema errors or unsupported claims, fix the files (cite real line IDs or remove the claim) and run it again, at most twice. If it reports a leak, remove the leaked text and re-run.
5. **Answer the user** in ≤ 12 lines: root cause, service, trigger, confidence, 2–3 evidence line IDs, top red herring rejected, evidence-check result, and the path to `report.html`. In `triage` mode: ≤ 10 lines total.

## Checks before you start
If anything fails oddly, run `python scripts/doctor.py --logs <logs>` and relay its fixes.

## Rules
- Read-only: never change systems, configs or services; never call the network.
- Stay within `<output_dir>`; don't modify the user's log files.
- Don't paste large script outputs into the chat; summarise.
- If the evidence is weak, say so: `insufficient_evidence` is a valid result.
