---
description: Investigate an incident from log files and produce an evidence-backed RCA, post-mortem and HTML report.
argument-hint: "<logs path> [deploys.json] [service_map.json] [symptom]"
input:
  - name: logs
    description: Log file or folder (JSONL, JSON, CSV, CloudWatch, Datadog, Elastic, syslog, plain text)
  - name: deploys
    description: Optional deploys/changes JSON file
  - name: service_map
    description: Optional service map (JSON or simple YAML)
  - name: symptom
    description: Optional description of what users saw
---

Use the run-incident-analysis skill in `full` mode.

- logs: $logs
- deploys: $deploys
- service_map: $service_map
- symptom: $symptom
- output_dir: ./incident-report

Leave out any parameter that is empty. Finish with the ≤12-line answer described in the skill and the path to report.html.
