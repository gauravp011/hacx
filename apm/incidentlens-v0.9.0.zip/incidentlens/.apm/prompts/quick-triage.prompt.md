---
description: Fast incident triage from logs - top root-cause hypothesis with evidence in under 10 lines.
argument-hint: "<logs path> [deploys.json] [symptom]"
input:
  - name: logs
    description: Log file or folder
  - name: deploys
    description: Optional deploys/changes JSON file
  - name: symptom
    description: What users are seeing right now
---

Use the run-incident-analysis skill in `triage` mode.

- logs: $logs
- deploys: $deploys
- symptom: $symptom
- output_dir: ./incident-report

Leave out empty parameters. Answer in at most 10 lines: likely root cause, service, trigger, confidence, 2 evidence line IDs, and the single most useful next check.
